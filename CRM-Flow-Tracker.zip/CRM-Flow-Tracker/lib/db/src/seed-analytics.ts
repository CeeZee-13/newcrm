import { db } from "./index";
import { companiesTable, contactsTable, dealsTable, activitiesTable } from "./schema";

const REPS = ["Alice Chen", "Bob Martinez", "Carol Lee", "David Kim"];
const SOURCES = ["Website", "Referral", "Cold Call", "LinkedIn", "Email Campaign", "Event", "Partner"];

function monthsAgo(n: number): Date {
  const d = new Date();
  d.setMonth(d.getMonth() - n);
  return d;
}
function daysAgo(n: number): Date {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return d;
}
function randomItem<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

async function seed() {
  console.log("Clearing existing data...");
  await db.delete(activitiesTable);
  await db.delete(dealsTable);
  await db.delete(contactsTable);
  await db.delete(companiesTable);

  console.log("Seeding companies...");
  const companies = await db.insert(companiesTable).values([
    { name: "Acme Corp", industry: "Technology", website: "https://acme.com", phone: "555-0100", address: "123 Main St, SF CA", createdAt: monthsAgo(12) },
    { name: "BuildRight Construction", industry: "Construction", website: "https://buildright.com", phone: "555-0200", address: "456 Oak Ave, Austin TX", createdAt: monthsAgo(11) },
    { name: "GlobalFinance Partners", industry: "Finance", website: "https://gfpartners.com", phone: "555-0300", address: "789 Wall St, New York NY", createdAt: monthsAgo(10) },
    { name: "MediCore Health", industry: "Healthcare", website: "https://medicore.io", phone: "555-0400", address: "101 Health Blvd, Boston MA", createdAt: monthsAgo(9) },
    { name: "RetailEdge Inc", industry: "Retail", website: "https://retailedge.com", phone: "555-0500", address: "222 Commerce Dr, Chicago IL", createdAt: monthsAgo(8) },
    { name: "CloudScale Systems", industry: "Technology", website: "https://cloudscale.io", phone: "555-0600", address: "33 Cloud Way, Seattle WA", createdAt: monthsAgo(7) },
    { name: "EnergyFirst Corp", industry: "Energy", website: "https://energyfirst.com", phone: "555-0700", address: "500 Power Ln, Houston TX", createdAt: monthsAgo(6) },
    { name: "ProLogistics LLC", industry: "Logistics", website: "https://prologistics.com", phone: "555-0800", address: "88 Supply Chain Rd, Atlanta GA", createdAt: monthsAgo(5) },
  ]).returning();

  console.log("Seeding contacts...");
  const contacts = await db.insert(contactsTable).values([
    { firstName: "James", lastName: "Carter", email: "jcarter@acme.com", phone: "555-1001", jobTitle: "CTO", companyId: companies[0].id, createdAt: monthsAgo(12) },
    { firstName: "Sarah", lastName: "Thompson", email: "sthompson@acme.com", phone: "555-1002", jobTitle: "VP Engineering", companyId: companies[0].id, createdAt: monthsAgo(11) },
    { firstName: "Mike", lastName: "Davis", email: "mdavis@buildright.com", phone: "555-1003", jobTitle: "CEO", companyId: companies[1].id, createdAt: monthsAgo(10) },
    { firstName: "Lisa", lastName: "Wang", email: "lwang@gfpartners.com", phone: "555-1004", jobTitle: "CFO", companyId: companies[2].id, createdAt: monthsAgo(9) },
    { firstName: "Tom", lastName: "Nakamura", email: "tnakamura@medicore.io", phone: "555-1005", jobTitle: "Director IT", companyId: companies[3].id, createdAt: monthsAgo(9) },
    { firstName: "Anna", lastName: "Petrov", email: "apetrov@retailedge.com", phone: "555-1006", jobTitle: "COO", companyId: companies[4].id, createdAt: monthsAgo(8) },
    { firstName: "Kevin", lastName: "Brooks", email: "kbrooks@cloudscale.io", phone: "555-1007", jobTitle: "CTO", companyId: companies[5].id, createdAt: monthsAgo(7) },
    { firstName: "Maria", lastName: "Santos", email: "msantos@energyfirst.com", phone: "555-1008", jobTitle: "VP Operations", companyId: companies[6].id, createdAt: monthsAgo(6) },
    { firstName: "Robert", lastName: "Hill", email: "rhill@prologistics.com", phone: "555-1009", jobTitle: "Procurement Manager", companyId: companies[7].id, createdAt: monthsAgo(5) },
    { firstName: "Jessica", lastName: "Moore", email: "jmoore@acme.com", phone: "555-1010", jobTitle: "Buyer", companyId: companies[0].id, createdAt: monthsAgo(4) },
    { firstName: "Chris", lastName: "Evans", email: "cevans@buildright.com", phone: "555-1011", jobTitle: "Project Lead", companyId: companies[1].id, createdAt: monthsAgo(3) },
    { firstName: "Nina", lastName: "Rodriguez", email: "nrodriguez@gfpartners.com", phone: "555-1012", jobTitle: "Director Finance", companyId: companies[2].id, createdAt: monthsAgo(2) },
  ]).returning();

  console.log("Seeding deals...");
  const dealRows = [
    // CLOSED WON - spread across months for MRR trend
    { title: "Acme Platform Upgrade", stage: "closed_won", capex: "150000", opex: "48000", mrr: "16500", source: "Referral", assignedTo: "Alice Chen", companyId: companies[0].id, contactId: contacts[0].id, probability: 100, expectedCloseDate: "2025-05-15", createdAt: monthsAgo(11) },
    { title: "BuildRight Project Mgmt Tool", stage: "closed_won", capex: "45000", opex: "18000", mrr: "5250", source: "Cold Call", assignedTo: "Bob Martinez", companyId: companies[1].id, contactId: contacts[2].id, probability: 100, expectedCloseDate: "2025-06-20", createdAt: monthsAgo(10) },
    { title: "MediCore EMR Integration", stage: "closed_won", capex: "220000", opex: "60000", mrr: "23333", source: "Website", assignedTo: "Carol Lee", companyId: companies[3].id, contactId: contacts[4].id, probability: 100, expectedCloseDate: "2025-07-10", createdAt: monthsAgo(9) },
    { title: "RetailEdge POS System", stage: "closed_won", capex: "80000", opex: "24000", mrr: "8667", source: "Event", assignedTo: "David Kim", companyId: companies[4].id, contactId: contacts[5].id, probability: 100, expectedCloseDate: "2025-08-05", createdAt: monthsAgo(8) },
    { title: "CloudScale Dev Tools License", stage: "closed_won", capex: "60000", opex: "36000", mrr: "8000", source: "LinkedIn", assignedTo: "Alice Chen", companyId: companies[5].id, contactId: contacts[6].id, probability: 100, expectedCloseDate: "2025-09-12", createdAt: monthsAgo(7) },
    { title: "GlobalFinance Analytics Suite", stage: "closed_won", capex: "310000", opex: "90000", mrr: "33333", source: "Partner", assignedTo: "Bob Martinez", companyId: companies[2].id, contactId: contacts[3].id, probability: 100, expectedCloseDate: "2025-10-01", createdAt: monthsAgo(6) },
    { title: "EnergyFirst SCADA Upgrade", stage: "closed_won", capex: "180000", opex: "54000", mrr: "19500", source: "Referral", assignedTo: "Carol Lee", companyId: companies[6].id, contactId: contacts[7].id, probability: 100, expectedCloseDate: "2025-11-18", createdAt: monthsAgo(5) },
    { title: "ProLogistics Fleet Tracker", stage: "closed_won", capex: "95000", opex: "30000", mrr: "10417", source: "Email Campaign", assignedTo: "David Kim", companyId: companies[7].id, contactId: contacts[8].id, probability: 100, expectedCloseDate: "2025-12-20", createdAt: monthsAgo(4) },
    { title: "Acme Mobile App v2", stage: "closed_won", capex: "70000", opex: "21000", mrr: "7583", source: "Referral", assignedTo: "Alice Chen", companyId: companies[0].id, contactId: contacts[1].id, probability: 100, expectedCloseDate: "2026-01-15", createdAt: monthsAgo(3) },
    { title: "BuildRight Safety Compliance", stage: "closed_won", capex: "40000", opex: "12000", mrr: "4333", source: "Cold Call", assignedTo: "Bob Martinez", companyId: companies[1].id, contactId: contacts[10].id, probability: 100, expectedCloseDate: "2026-02-10", createdAt: monthsAgo(2) },
    { title: "CloudScale Security Audit", stage: "closed_won", capex: "55000", opex: "18000", mrr: "6083", source: "LinkedIn", assignedTo: "Carol Lee", companyId: companies[5].id, contactId: contacts[6].id, probability: 100, expectedCloseDate: "2026-03-01", createdAt: monthsAgo(1) },
    // CLOSED LOST
    { title: "MediCore Legacy Migration", stage: "closed_lost", capex: "200000", opex: "60000", mrr: null, source: "Website", assignedTo: "David Kim", companyId: companies[3].id, contactId: contacts[4].id, probability: 0, expectedCloseDate: "2025-08-30", createdAt: monthsAgo(10) },
    { title: "RetailEdge Warehouse System", stage: "closed_lost", capex: "130000", opex: "42000", mrr: null, source: "Cold Call", assignedTo: "Alice Chen", companyId: companies[4].id, contactId: contacts[5].id, probability: 0, expectedCloseDate: "2025-09-15", createdAt: monthsAgo(8) },
    { title: "EnergyFirst IoT Platform", stage: "closed_lost", capex: "250000", opex: "72000", mrr: null, source: "Event", assignedTo: "Bob Martinez", companyId: companies[6].id, contactId: contacts[7].id, probability: 0, expectedCloseDate: "2025-10-20", createdAt: monthsAgo(6) },
    { title: "ProLogistics CRM Rollout", stage: "closed_lost", capex: "85000", opex: "27000", mrr: null, source: "Referral", assignedTo: "Carol Lee", companyId: companies[7].id, contactId: contacts[8].id, probability: 0, expectedCloseDate: "2025-12-01", createdAt: monthsAgo(4) },
    // OPEN PIPELINE
    { title: "Acme Mobile App", stage: "lead", capex: "60000", opex: "24000", mrr: null, source: "Website", assignedTo: "Alice Chen", companyId: companies[0].id, contactId: contacts[0].id, probability: 20, expectedCloseDate: "2026-06-30", createdAt: daysAgo(90) },
    { title: "GlobalFinance Reporting Tool", stage: "appointment_scheduled", capex: "95000", opex: "30000", mrr: null, source: "LinkedIn", assignedTo: "Bob Martinez", companyId: companies[2].id, contactId: contacts[11].id, probability: 35, expectedCloseDate: "2026-05-15", createdAt: daysAgo(60) },
    { title: "MediCore Patient Portal", stage: "demo_given", capex: "175000", opex: "52000", mrr: null, source: "Partner", assignedTo: "Carol Lee", companyId: companies[3].id, contactId: contacts[4].id, probability: 55, expectedCloseDate: "2026-05-30", createdAt: daysAgo(45) },
    { title: "RetailEdge Analytics", stage: "contract_sent", capex: "280000", opex: "84000", mrr: null, source: "Email Campaign", assignedTo: "David Kim", companyId: companies[4].id, contactId: contacts[9].id, probability: 80, expectedCloseDate: "2026-04-30", createdAt: daysAgo(30) },
    { title: "CloudScale Data Pipeline", stage: "demo_given", capex: "120000", opex: "36000", mrr: null, source: "Referral", assignedTo: "Alice Chen", companyId: companies[5].id, contactId: contacts[6].id, probability: 60, expectedCloseDate: "2026-06-15", createdAt: daysAgo(20) },
    { title: "EnergyFirst Billing Overhaul", stage: "lead", capex: "200000", opex: "60000", mrr: null, source: "Cold Call", assignedTo: "Bob Martinez", companyId: companies[6].id, contactId: contacts[7].id, probability: 15, expectedCloseDate: "2026-07-01", createdAt: daysAgo(10) },
    { title: "ProLogistics Inventory Mgmt", stage: "appointment_scheduled", capex: "75000", opex: "24000", mrr: null, source: "Website", assignedTo: "Carol Lee", companyId: companies[7].id, contactId: contacts[8].id, probability: 30, expectedCloseDate: "2026-06-01", createdAt: daysAgo(5) },
  ];

  const deals = await db.insert(dealsTable).values(dealRows.map(d => ({
    ...d,
    createdAt: d.createdAt,
  }))).returning();

  console.log("Seeding activities (calls, meetings, notes)...");
  const activityRows: any[] = [];

  // Generate rich activity data over 12 months for analytics
  const callOutcomes = ["Left voicemail", "No answer", "Interested", "Call back later", "Not interested", "Meeting booked", "Demo scheduled"];
  const meetingOutcomes = ["Demo completed", "Follow-up needed", "Proposal sent", "Contract review", "Signed", "Postponed"];

  // For each deal, create a realistic activity history
  for (const deal of deals) {
    const daysBack = Math.floor((Date.now() - new Date(deal.createdAt).getTime()) / (1000 * 60 * 60 * 24));
    const rep = deal.assignedTo || randomItem(REPS);

    // Notes
    activityRows.push({
      dealId: deal.id,
      type: "note",
      title: "Initial qualification notes",
      content: "Prospect is evaluating multiple vendors. Budget confirmed.",
      rep,
      createdAt: new Date(new Date(deal.createdAt).getTime() + 1000 * 60 * 60 * 2),
    });

    // Calls spread over time
    const callCount = Math.floor(Math.random() * 5) + 2;
    for (let i = 0; i < callCount; i++) {
      const daysOffset = Math.floor((daysBack * i) / callCount);
      const isConnected = Math.random() > 0.45;
      activityRows.push({
        dealId: deal.id,
        contactId: deal.contactId,
        type: "call",
        title: isConnected ? "Connected call" : "Call attempt",
        content: isConnected ? randomItem(callOutcomes.slice(2)) : randomItem(callOutcomes.slice(0, 2)),
        connected: isConnected,
        duration: isConnected ? Math.floor(Math.random() * 25 + 5) : null,
        rep,
        createdAt: daysAgo(daysBack - daysOffset),
      });
    }

    // Meetings for deals past lead stage
    if (!["lead", "closed_lost"].includes(deal.stage)) {
      const meetingCount = deal.stage === "closed_won" ? Math.floor(Math.random() * 3) + 2 : Math.floor(Math.random() * 2) + 1;
      for (let i = 0; i < meetingCount; i++) {
        const daysOffset = Math.floor((daysBack * (i + 1)) / (meetingCount + 1));
        activityRows.push({
          dealId: deal.id,
          contactId: deal.contactId,
          type: "meeting",
          title: i === 0 ? "Discovery call" : i === 1 ? "Product demo" : "Contract review",
          content: randomItem(meetingOutcomes),
          duration: Math.floor(Math.random() * 45 + 30),
          rep,
          createdAt: daysAgo(daysBack - daysOffset),
          scheduledAt: daysAgo(daysBack - daysOffset),
        });
      }
    }

    // Emails for most deals
    if (Math.random() > 0.3) {
      activityRows.push({
        dealId: deal.id,
        contactId: deal.contactId,
        type: "email",
        title: "Follow-up email sent",
        content: "Sent proposal and pricing breakdown.",
        rep,
        createdAt: daysAgo(Math.floor(daysBack * 0.5)),
      });
    }
  }

  // Extra standalone calls to pad rep stats across months
  const extraCallDates = [
    daysAgo(180), daysAgo(165), daysAgo(150), daysAgo(140), daysAgo(130),
    daysAgo(120), daysAgo(110), daysAgo(100), daysAgo(90), daysAgo(80),
    daysAgo(70), daysAgo(60), daysAgo(50), daysAgo(40), daysAgo(30),
    daysAgo(20), daysAgo(15), daysAgo(10), daysAgo(7), daysAgo(3), daysAgo(1),
  ];

  for (const date of extraCallDates) {
    for (const rep of REPS) {
      const callsThisDay = Math.floor(Math.random() * 4) + 1;
      for (let i = 0; i < callsThisDay; i++) {
        const isConnected = Math.random() > 0.5;
        activityRows.push({
          dealId: deals[Math.floor(Math.random() * deals.length)].id,
          type: "call",
          title: isConnected ? "Connected call" : "Call attempt",
          connected: isConnected,
          duration: isConnected ? Math.floor(Math.random() * 20 + 5) : null,
          rep,
          createdAt: new Date(date.getTime() + Math.random() * 1000 * 60 * 60 * 8),
        });
      }
    }
  }

  // Extra meetings
  const extraMeetingDates = [
    daysAgo(170), daysAgo(145), daysAgo(120), daysAgo(100), daysAgo(80),
    daysAgo(60), daysAgo(45), daysAgo(30), daysAgo(15), daysAgo(5),
  ];

  for (const date of extraMeetingDates) {
    for (const rep of REPS) {
      if (Math.random() > 0.4) {
        activityRows.push({
          dealId: deals[Math.floor(Math.random() * deals.length)].id,
          type: "meeting",
          title: "Demo meeting",
          content: randomItem(meetingOutcomes),
          duration: Math.floor(Math.random() * 45 + 20),
          rep,
          createdAt: new Date(date.getTime() + Math.random() * 1000 * 60 * 60 * 6),
          scheduledAt: new Date(date.getTime() + Math.random() * 1000 * 60 * 60 * 6),
        });
      }
    }
  }

  // Batch insert activities
  const batchSize = 50;
  for (let i = 0; i < activityRows.length; i += batchSize) {
    await db.insert(activitiesTable).values(activityRows.slice(i, i + batchSize));
  }

  console.log(`Seeded: ${companies.length} companies, ${contacts.length} contacts, ${deals.length} deals, ${activityRows.length} activities`);
}

seed().then(() => {
  console.log("Done!");
  process.exit(0);
}).catch((err) => {
  console.error(err);
  process.exit(1);
});
