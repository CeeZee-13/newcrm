import { pgTable, text, serial, integer, numeric, date, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const dealsTable = pgTable("deals", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  stage: text("stage").notNull().default("lead"),
  capex: numeric("capex", { precision: 15, scale: 2 }),
  opex: numeric("opex", { precision: 15, scale: 2 }),
  mrr: numeric("mrr", { precision: 15, scale: 2 }),
  currency: text("currency").notNull().default("USD"),
  probability: integer("probability"),
  expectedCloseDate: date("expected_close_date"),
  contactId: integer("contact_id"),
  companyId: integer("company_id"),
  source: text("source"),
  assignedTo: text("assigned_to"),
  description: text("description"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertDealSchema = createInsertSchema(dealsTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertDeal = z.infer<typeof insertDealSchema>;
export type Deal = typeof dealsTable.$inferSelect;
