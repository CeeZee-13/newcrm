import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const activitiesTable = pgTable("activities", {
  id: serial("id").primaryKey(),
  dealId: integer("deal_id"),
  contactId: integer("contact_id"),
  type: text("type").notNull().default("note"),
  title: text("title").notNull(),
  content: text("content"),
  scheduledAt: timestamp("scheduled_at", { withTimezone: true }),
  duration: integer("duration"),
  outcome: text("outcome"),
  connected: boolean("connected"),
  rep: text("rep"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertActivitySchema = createInsertSchema(activitiesTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertActivity = z.infer<typeof insertActivitySchema>;
export type Activity = typeof activitiesTable.$inferSelect;
