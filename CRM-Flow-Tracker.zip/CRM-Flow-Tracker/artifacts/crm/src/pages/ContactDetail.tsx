import { useState } from "react";
import { useParams, Link } from "wouter";
import { useGetContact, useUpdateContact, useDeleteContact, useListDeals, useListActivities, useListCompanies, getGetContactQueryKey, getListContactsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { formatDateTime } from "@/lib/utils";
import StageBadge from "@/components/StageBadge";
import ActivityBadge from "@/components/ActivityBadge";
import ActivityModal from "@/components/ActivityModal";
import { ArrowLeft, Pencil, Check, X, Plus, Trash2 } from "lucide-react";
import { formatCurrency } from "@/lib/utils";

export default function ContactDetail() {
  const params = useParams<{ id: string }>();
  const id = parseInt(params.id, 10);
  const queryClient = useQueryClient();

  const { data: contact, isLoading } = useGetContact(id, { query: { enabled: !!id, queryKey: getGetContactQueryKey(id) } });
  const { data: deals = [] } = useListDeals();
  const { data: activities = [] } = useListActivities({ contactId: id });
  const { data: companies = [] } = useListCompanies();
  const updateContact = useUpdateContact();
  const deleteContact = useDeleteContact();
  const [editing, setEditing] = useState(false);
  const [showActivity, setShowActivity] = useState(false);

  const { register, handleSubmit, reset } = useForm();

  const startEdit = () => {
    if (!contact) return;
    reset({
      firstName: contact.firstName,
      lastName: contact.lastName,
      email: contact.email ?? "",
      phone: contact.phone ?? "",
      jobTitle: contact.jobTitle ?? "",
      companyId: contact.companyId ?? "",
      notes: contact.notes ?? "",
    });
    setEditing(true);
  };

  const onSubmit = (data: Record<string, unknown>) => {
    updateContact.mutate({
      id,
      data: {
        firstName: data.firstName as string,
        lastName: data.lastName as string,
        email: data.email ? String(data.email) : null,
        phone: data.phone ? String(data.phone) : null,
        jobTitle: data.jobTitle ? String(data.jobTitle) : null,
        companyId: data.companyId ? parseInt(data.companyId as string) : null,
        notes: data.notes ? String(data.notes) : null,
      },
    }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetContactQueryKey(id) });
        queryClient.invalidateQueries({ queryKey: getListContactsQueryKey() });
        setEditing(false);
      },
    });
  };

  const contactDeals = deals.filter((d) => d.contactId === id);

  if (isLoading) return <div className="p-6 text-muted-foreground">Loading...</div>;
  if (!contact) return <div className="p-6 text-muted-foreground">Contact not found</div>;

  return (
    <div className="p-6 max-w-4xl">
      <Link href="/contacts" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground mb-6 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to Contacts
      </Link>

      <div className="flex items-start justify-between mb-6">
        <div>
          {editing ? (
            <div className="flex gap-2">
              <input {...register("firstName")} className="text-2xl font-bold bg-transparent border-b border-primary focus:outline-none" />
              <input {...register("lastName")} className="text-2xl font-bold bg-transparent border-b border-primary focus:outline-none" />
            </div>
          ) : (
            <h1 className="text-2xl font-bold text-foreground">{contact.firstName} {contact.lastName}</h1>
          )}
          <p className="text-sm text-muted-foreground mt-1">{contact.jobTitle ?? ""} {contact.companyName ? `at ${contact.companyName}` : ""}</p>
        </div>
        <div className="flex gap-2">
          {editing ? (
            <>
              <button onClick={handleSubmit(onSubmit)} className="flex items-center gap-1.5 px-3 py-1.5 bg-primary text-primary-foreground rounded-md text-sm font-medium hover:opacity-90 transition-opacity">
                <Check className="w-3.5 h-3.5" /> Save
              </button>
              <button onClick={() => setEditing(false)} className="flex items-center gap-1.5 px-3 py-1.5 border border-border rounded-md text-sm hover:bg-muted transition-colors">
                <X className="w-3.5 h-3.5" /> Cancel
              </button>
            </>
          ) : (
            <>
              <button onClick={startEdit} className="flex items-center gap-1.5 px-3 py-1.5 border border-border rounded-md text-sm hover:bg-muted transition-colors">
                <Pencil className="w-3.5 h-3.5" /> Edit
              </button>
              <button
                onClick={() => {
                  if (confirm("Delete this contact?")) {
                    deleteContact.mutate({ id }, { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListContactsQueryKey() }); window.history.back(); } });
                  }
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 border border-red-200 text-red-600 rounded-md text-sm hover:bg-red-50 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" /> Delete
              </button>
            </>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-card border border-card-border rounded-lg p-5">
            <h2 className="font-semibold text-foreground mb-4">Contact Info</h2>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-xs text-muted-foreground mb-1">Email</p>
                {editing ? <input {...register("email")} type="email" className="border border-input rounded px-2 py-1 text-sm w-full bg-background focus:outline-none" /> : <p className="font-medium">{contact.email ?? "-"}</p>}
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-1">Phone</p>
                {editing ? <input {...register("phone")} className="border border-input rounded px-2 py-1 text-sm w-full bg-background focus:outline-none" /> : <p className="font-medium">{contact.phone ?? "-"}</p>}
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-1">Job Title</p>
                {editing ? <input {...register("jobTitle")} className="border border-input rounded px-2 py-1 text-sm w-full bg-background focus:outline-none" /> : <p className="font-medium">{contact.jobTitle ?? "-"}</p>}
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-1">Company</p>
                {editing ? (
                  <select {...register("companyId")} className="border border-input rounded px-2 py-1 text-sm w-full bg-background focus:outline-none">
                    <option value="">No company</option>
                    {companies.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                ) : <p className="font-medium">{contact.companyName ?? "-"}</p>}
              </div>
              <div className="col-span-2">
                <p className="text-xs text-muted-foreground mb-1">Notes</p>
                {editing ? <textarea {...register("notes")} rows={3} className="w-full border border-input rounded px-2 py-1.5 text-sm bg-background focus:outline-none resize-none" /> : <p className="text-foreground">{contact.notes ?? "-"}</p>}
              </div>
            </div>
          </div>

          {/* Deals */}
          {contactDeals.length > 0 && (
            <div className="bg-card border border-card-border rounded-lg p-5">
              <h2 className="font-semibold text-foreground mb-4">Deals</h2>
              <div className="space-y-2">
                {contactDeals.map((d) => (
                  <Link key={d.id} href={`/deals/${d.id}`} className="flex items-center justify-between p-3 rounded-md border border-border hover:bg-muted/30 transition-colors">
                    <div>
                      <p className="text-sm font-medium text-foreground">{d.title}</p>
                      <StageBadge stage={d.stage} className="mt-1" />
                    </div>
                    <p className="text-sm font-semibold">{formatCurrency(d.totalValue)}</p>
                  </Link>
                ))}
              </div>
            </div>
          )}

          {/* Activity */}
          <div className="bg-card border border-card-border rounded-lg p-5">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-semibold text-foreground">Activity</h2>
              <button onClick={() => setShowActivity(true)} className="flex items-center gap-1.5 px-3 py-1.5 bg-primary text-primary-foreground rounded-md text-xs font-medium hover:opacity-90">
                <Plus className="w-3 h-3" /> Log
              </button>
            </div>
            {activities.length === 0 ? (
              <p className="text-sm text-muted-foreground">No activities yet</p>
            ) : activities.map((a) => (
              <div key={a.id} className="flex gap-3 py-3 border-b border-border/60 last:border-0">
                <ActivityBadge type={a.type} />
                <div>
                  <p className="text-sm font-medium text-foreground">{a.title}</p>
                  {a.content && <p className="text-sm text-muted-foreground">{a.content}</p>}
                  <p className="text-xs text-muted-foreground mt-1">{formatDateTime(a.scheduledAt ?? a.createdAt)}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div>
          <div className="bg-card border border-card-border rounded-lg p-4 text-sm">
            <h3 className="font-semibold text-foreground mb-3">Record Info</h3>
            <div className="space-y-2">
              <div><p className="text-xs text-muted-foreground">Created</p><p>{formatDateTime(contact.createdAt)}</p></div>
              <div><p className="text-xs text-muted-foreground">Last Updated</p><p>{formatDateTime(contact.updatedAt)}</p></div>
            </div>
          </div>
        </div>
      </div>

      {showActivity && (
        <ActivityModal
          contactId={id}
          onClose={() => setShowActivity(false)}
          onSuccess={() => { queryClient.invalidateQueries({ queryKey: ["/activities"] }); setShowActivity(false); }}
        />
      )}
    </div>
  );
}
