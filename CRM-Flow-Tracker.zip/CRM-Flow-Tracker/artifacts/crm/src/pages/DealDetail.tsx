import { useState } from "react";
import { useParams, Link } from "wouter";
import { useGetDeal, useUpdateDeal, useListActivities, useDeleteDeal, getGetDealQueryKey, getListActivitiesQueryKey, getListDealsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { formatCurrency, formatDate, formatDateTime, STAGES } from "@/lib/utils";
import StageBadge from "@/components/StageBadge";
import ActivityBadge from "@/components/ActivityBadge";
import ActivityModal from "@/components/ActivityModal";
import { ArrowLeft, Pencil, Check, X, Plus, Trash2 } from "lucide-react";

export default function DealDetail() {
  const params = useParams<{ id: string }>();
  const id = parseInt(params.id, 10);
  const queryClient = useQueryClient();

  const { data: deal, isLoading } = useGetDeal(id, { query: { enabled: !!id, queryKey: getGetDealQueryKey(id) } });
  const { data: activities = [] } = useListActivities({ dealId: id });
  const updateDeal = useUpdateDeal();
  const deleteDeal = useDeleteDeal();
  const [editing, setEditing] = useState(false);
  const [showActivity, setShowActivity] = useState(false);

  const { register, handleSubmit, reset } = useForm();

  const startEdit = () => {
    if (!deal) return;
    reset({
      title: deal.title,
      stage: deal.stage,
      capex: deal.capex ?? "",
      opex: deal.opex ?? "",
      probability: deal.probability ?? "",
      expectedCloseDate: deal.expectedCloseDate ?? "",
      description: deal.description ?? "",
    });
    setEditing(true);
  };

  const onSubmit = (data: Record<string, unknown>) => {
    updateDeal.mutate({
      id,
      data: {
        title: data.title as string,
        stage: data.stage as string,
        capex: data.capex ? parseFloat(data.capex as string) : null,
        opex: data.opex ? parseFloat(data.opex as string) : null,
        probability: data.probability ? parseInt(data.probability as string) : null,
        expectedCloseDate: data.expectedCloseDate ? String(data.expectedCloseDate) : null,
        description: data.description ? String(data.description) : null,
      },
    }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetDealQueryKey(id) });
        queryClient.invalidateQueries({ queryKey: getListDealsQueryKey() });
        setEditing(false);
      },
    });
  };

  if (isLoading) return <div className="p-6 text-muted-foreground">Loading...</div>;
  if (!deal) return <div className="p-6 text-muted-foreground">Deal not found</div>;

  return (
    <div className="p-6 max-w-4xl">
      {/* Back */}
      <Link href="/deals" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground mb-6 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to Deals
      </Link>

      {/* Header */}
      <div className="flex items-start justify-between mb-6">
        <div>
          {editing ? (
            <input {...register("title")} className="text-2xl font-bold bg-transparent border-b border-primary focus:outline-none w-full" />
          ) : (
            <h1 className="text-2xl font-bold text-foreground">{deal.title}</h1>
          )}
          <div className="flex items-center gap-3 mt-2">
            {editing ? (
              <select {...register("stage")} className="border border-input rounded-md px-2 py-1 text-sm bg-background">
                {STAGES.map((s) => <option key={s.key} value={s.key}>{s.label}</option>)}
              </select>
            ) : (
              <StageBadge stage={deal.stage} />
            )}
            {deal.companyName && <span className="text-sm text-muted-foreground">{deal.companyName}</span>}
            {deal.contactName && <span className="text-sm text-muted-foreground">{deal.contactName}</span>}
          </div>
        </div>
        <div className="flex gap-2">
          {editing ? (
            <>
              <button onClick={handleSubmit(onSubmit)} className="flex items-center gap-1.5 px-3 py-1.5 bg-primary text-primary-foreground rounded-md text-sm font-medium hover:opacity-90 transition-opacity">
                <Check className="w-3.5 h-3.5" /> Save
              </button>
              <button onClick={() => setEditing(false)} className="flex items-center gap-1.5 px-3 py-1.5 border border-border rounded-md text-sm hover:bg-muted transition-colors">
                <X className="w-3.5 h-3.5" /> Cancel
              </button>
            </>
          ) : (
            <>
              <button onClick={startEdit} className="flex items-center gap-1.5 px-3 py-1.5 border border-border rounded-md text-sm hover:bg-muted transition-colors">
                <Pencil className="w-3.5 h-3.5" /> Edit
              </button>
              <button
                onClick={() => {
                  if (confirm("Delete this deal?")) {
                    deleteDeal.mutate({ id }, { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListDealsQueryKey() }); window.history.back(); } });
                  }
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 border border-red-200 text-red-600 rounded-md text-sm hover:bg-red-50 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" /> Delete
              </button>
            </>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: deal info */}
        <div className="lg:col-span-2 space-y-4">
          {/* Capex / Opex card */}
          <div className="bg-card border border-card-border rounded-lg p-5">
            <h2 className="font-semibold text-foreground mb-4">Deal Value</h2>
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-blue-50 border border-blue-100 rounded-lg p-4">
                <p className="text-xs font-medium text-blue-600 mb-1">Capex</p>
                {editing ? (
                  <input {...register("capex")} type="number" step="0.01" className="w-full bg-transparent text-xl font-bold text-blue-800 focus:outline-none border-b border-blue-300" />
                ) : (
                  <p className="text-xl font-bold text-blue-800">{formatCurrency(deal.capex)}</p>
                )}
              </div>
              <div className="bg-amber-50 border border-amber-100 rounded-lg p-4">
                <p className="text-xs font-medium text-amber-600 mb-1">Opex</p>
                {editing ? (
                  <input {...register("opex")} type="number" step="0.01" className="w-full bg-transparent text-xl font-bold text-amber-800 focus:outline-none border-b border-amber-300" />
                ) : (
                  <p className="text-xl font-bold text-amber-800">{formatCurrency(deal.opex)}</p>
                )}
              </div>
              <div className="bg-green-50 border border-green-100 rounded-lg p-4">
                <p className="text-xs font-medium text-green-600 mb-1">Total Value</p>
                <p className="text-xl font-bold text-green-800">{formatCurrency(deal.totalValue)}</p>
              </div>
            </div>
          </div>

          {/* Details */}
          <div className="bg-card border border-card-border rounded-lg p-5">
            <h2 className="font-semibold text-foreground mb-4">Details</h2>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-xs text-muted-foreground mb-1">Probability</p>
                {editing ? (
                  <input {...register("probability")} type="number" min="0" max="100" className="border border-input rounded px-2 py-1 text-sm w-24 bg-background focus:outline-none" />
                ) : (
                  <p className="font-medium">{deal.probability != null ? `${deal.probability}%` : "-"}</p>
                )}
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-1">Expected Close Date</p>
                {editing ? (
                  <input {...register("expectedCloseDate")} type="date" className="border border-input rounded px-2 py-1 text-sm bg-background focus:outline-none" />
                ) : (
                  <p className="font-medium">{formatDate(deal.expectedCloseDate)}</p>
                )}
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-1">Contact</p>
                <p className="font-medium">{deal.contactName ?? "-"}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-1">Company</p>
                <p className="font-medium">{deal.companyName ?? "-"}</p>
              </div>
              <div className="col-span-2">
                <p className="text-xs text-muted-foreground mb-1">Description</p>
                {editing ? (
                  <textarea {...register("description")} rows={3} className="w-full border border-input rounded px-2 py-1.5 text-sm bg-background focus:outline-none resize-none" />
                ) : (
                  <p className="text-foreground">{deal.description ?? "-"}</p>
                )}
              </div>
            </div>
          </div>

          {/* Activity timeline */}
          <div className="bg-card border border-card-border rounded-lg p-5">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-semibold text-foreground">Activity</h2>
              <button
                onClick={() => setShowActivity(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-primary text-primary-foreground rounded-md text-xs font-medium hover:opacity-90 transition-opacity"
              >
                <Plus className="w-3 h-3" /> Log Activity
              </button>
            </div>
            {activities.length === 0 ? (
              <p className="text-sm text-muted-foreground">No activities logged yet</p>
            ) : (
              <div className="space-y-3">
                {activities.map((a) => (
                  <div key={a.id} className="flex gap-3 py-3 border-b border-border/60 last:border-0">
                    <ActivityBadge type={a.type} />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground">{a.title}</p>
                      {a.content && <p className="text-sm text-muted-foreground mt-0.5">{a.content}</p>}
                      {a.outcome && <p className="text-xs text-green-700 bg-green-50 rounded px-2 py-0.5 mt-1 inline-block">Outcome: {a.outcome}</p>}
                      <p className="text-xs text-muted-foreground mt-1">
                        {formatDateTime(a.scheduledAt ?? a.createdAt)}
                        {a.duration && <span className="ml-2">{a.duration} min</span>}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right: meta */}
        <div className="space-y-4">
          <div className="bg-card border border-card-border rounded-lg p-4 text-sm">
            <h3 className="font-semibold text-foreground mb-3">Record Info</h3>
            <div className="space-y-2">
              <div>
                <p className="text-xs text-muted-foreground">Created</p>
                <p className="text-foreground">{formatDateTime(deal.createdAt)}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Last Updated</p>
                <p className="text-foreground">{formatDateTime(deal.updatedAt)}</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {showActivity && (
        <ActivityModal
          dealId={id}
          onClose={() => setShowActivity(false)}
          onSuccess={() => {
            queryClient.invalidateQueries({ queryKey: getListActivitiesQueryKey({ dealId: id }) });
            setShowActivity(false);
          }}
        />
      )}
    </div>
  );
}
