import { useState } from "react";
import { useParams, Link } from "wouter";
import { useGetCompany, useUpdateCompany, useDeleteCompany, useListContacts, useListDeals, getGetCompanyQueryKey, getListCompaniesQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { formatDateTime, formatCurrency } from "@/lib/utils";
import StageBadge from "@/components/StageBadge";
import { ArrowLeft, Pencil, Check, X, Trash2, Globe } from "lucide-react";

export default function CompanyDetail() {
  const params = useParams<{ id: string }>();
  const id = parseInt(params.id, 10);
  const queryClient = useQueryClient();

  const { data: company, isLoading } = useGetCompany(id, { query: { enabled: !!id, queryKey: getGetCompanyQueryKey(id) } });
  const { data: contacts = [] } = useListContacts();
  const { data: deals = [] } = useListDeals();
  const updateCompany = useUpdateCompany();
  const deleteCompany = useDeleteCompany();
  const [editing, setEditing] = useState(false);

  const { register, handleSubmit, reset } = useForm();

  const startEdit = () => {
    if (!company) return;
    reset({ name: company.name, industry: company.industry ?? "", website: company.website ?? "", phone: company.phone ?? "", address: company.address ?? "", notes: company.notes ?? "" });
    setEditing(true);
  };

  const onSubmit = (data: Record<string, unknown>) => {
    updateCompany.mutate({
      id,
      data: {
        name: data.name as string,
        industry: data.industry ? String(data.industry) : null,
        website: data.website ? String(data.website) : null,
        phone: data.phone ? String(data.phone) : null,
        address: data.address ? String(data.address) : null,
        notes: data.notes ? String(data.notes) : null,
      },
    }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetCompanyQueryKey(id) });
        queryClient.invalidateQueries({ queryKey: getListCompaniesQueryKey() });
        setEditing(false);
      },
    });
  };

  const companyContacts = contacts.filter((c) => c.companyId === id);
  const companyDeals = deals.filter((d) => d.companyId === id);

  if (isLoading) return <div className="p-6 text-muted-foreground">Loading...</div>;
  if (!company) return <div className="p-6 text-muted-foreground">Company not found</div>;

  return (
    <div className="p-6 max-w-4xl">
      <Link href="/companies" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground mb-6 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to Companies
      </Link>

      <div className="flex items-start justify-between mb-6">
        <div>
          {editing ? (
            <input {...register("name")} className="text-2xl font-bold bg-transparent border-b border-primary focus:outline-none" />
          ) : (
            <h1 className="text-2xl font-bold text-foreground">{company.name}</h1>
          )}
          <p className="text-sm text-muted-foreground mt-1">{company.industry ?? ""}</p>
        </div>
        <div className="flex gap-2">
          {editing ? (
            <>
              <button onClick={handleSubmit(onSubmit)} className="flex items-center gap-1.5 px-3 py-1.5 bg-primary text-primary-foreground rounded-md text-sm font-medium hover:opacity-90 transition-opacity">
                <Check className="w-3.5 h-3.5" /> Save
              </button>
              <button onClick={() => setEditing(false)} className="flex items-center gap-1.5 px-3 py-1.5 border border-border rounded-md text-sm hover:bg-muted transition-colors">
                <X className="w-3.5 h-3.5" /> Cancel
              </button>
            </>
          ) : (
            <>
              <button onClick={startEdit} className="flex items-center gap-1.5 px-3 py-1.5 border border-border rounded-md text-sm hover:bg-muted transition-colors">
                <Pencil className="w-3.5 h-3.5" /> Edit
              </button>
              <button
                onClick={() => {
                  if (confirm("Delete this company?")) {
                    deleteCompany.mutate({ id }, { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListCompaniesQueryKey() }); window.history.back(); } });
                  }
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 border border-red-200 text-red-600 rounded-md text-sm hover:bg-red-50 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" /> Delete
              </button>
            </>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-card border border-card-border rounded-lg p-5">
            <h2 className="font-semibold text-foreground mb-4">Company Info</h2>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-xs text-muted-foreground mb-1">Industry</p>
                {editing ? <input {...register("industry")} className="border border-input rounded px-2 py-1 text-sm w-full bg-background focus:outline-none" /> : <p className="font-medium">{company.industry ?? "-"}</p>}
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-1">Phone</p>
                {editing ? <input {...register("phone")} className="border border-input rounded px-2 py-1 text-sm w-full bg-background focus:outline-none" /> : <p className="font-medium">{company.phone ?? "-"}</p>}
              </div>
              <div className="col-span-2">
                <p className="text-xs text-muted-foreground mb-1">Website</p>
                {editing ? <input {...register("website")} type="url" className="border border-input rounded px-2 py-1 text-sm w-full bg-background focus:outline-none" /> : (
                  company.website ? (
                    <a href={company.website} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 text-primary hover:underline font-medium">
                      <Globe className="w-3.5 h-3.5" />{company.website}
                    </a>
                  ) : <p className="font-medium">-</p>
                )}
              </div>
              <div className="col-span-2">
                <p className="text-xs text-muted-foreground mb-1">Address</p>
                {editing ? <input {...register("address")} className="border border-input rounded px-2 py-1 text-sm w-full bg-background focus:outline-none" /> : <p className="font-medium">{company.address ?? "-"}</p>}
              </div>
              <div className="col-span-2">
                <p className="text-xs text-muted-foreground mb-1">Notes</p>
                {editing ? <textarea {...register("notes")} rows={3} className="w-full border border-input rounded px-2 py-1.5 text-sm bg-background focus:outline-none resize-none" /> : <p className="text-foreground">{company.notes ?? "-"}</p>}
              </div>
            </div>
          </div>

          {/* Contacts */}
          {companyContacts.length > 0 && (
            <div className="bg-card border border-card-border rounded-lg p-5">
              <h2 className="font-semibold text-foreground mb-4">Contacts</h2>
              <div className="space-y-2">
                {companyContacts.map((c) => (
                  <Link key={c.id} href={`/contacts/${c.id}`} className="flex items-center justify-between p-3 rounded-md border border-border hover:bg-muted/30 transition-colors">
                    <p className="text-sm font-medium text-foreground">{c.firstName} {c.lastName}</p>
                    <p className="text-xs text-muted-foreground">{c.jobTitle ?? ""}</p>
                  </Link>
                ))}
              </div>
            </div>
          )}

          {/* Deals */}
          {companyDeals.length > 0 && (
            <div className="bg-card border border-card-border rounded-lg p-5">
              <h2 className="font-semibold text-foreground mb-4">Deals</h2>
              <div className="space-y-2">
                {companyDeals.map((d) => (
                  <Link key={d.id} href={`/deals/${d.id}`} className="flex items-center justify-between p-3 rounded-md border border-border hover:bg-muted/30 transition-colors">
                    <div>
                      <p className="text-sm font-medium text-foreground">{d.title}</p>
                      <StageBadge stage={d.stage} className="mt-1" />
                    </div>
                    <p className="text-sm font-semibold">{formatCurrency(d.totalValue)}</p>
                  </Link>
                ))}
              </div>
            </div>
          )}
        </div>

        <div>
          <div className="bg-card border border-card-border rounded-lg p-4 text-sm">
            <h3 className="font-semibold text-foreground mb-3">Record Info</h3>
            <div className="space-y-2">
              <div><p className="text-xs text-muted-foreground">Created</p><p>{formatDateTime(company.createdAt)}</p></div>
              <div><p className="text-xs text-muted-foreground">Last Updated</p><p>{formatDateTime(company.updatedAt)}</p></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
