import { useQuery } from "@tanstack/react-query";
import { useState, useEffect, useRef } from "react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, PieChart, Pie, Cell, Legend, AreaChart, Area,
} from "recharts";
import { TrendingUp, TrendingDown, Phone, Video, Target, Users, Briefcase, DollarSign, Clock, Zap, Pencil, Check, X } from "lucide-react";

const API = import.meta.env.BASE_URL.replace(/\/$/, "");

function fetchJson(path: string) {
  return fetch(`${API}${path}`).then((r) => r.json());
}

function formatCurrency(n: number | null | undefined, compact = false): string {
  if (n == null) return "$0";
  if (compact && n >= 1_000_000) return `$${(n / 1_000_000).toFixed(1)}M`;
  if (compact && n >= 1_000) return `$${(n / 1_000).toFixed(0)}K`;
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(n);
}

function formatMonth(m: string): string {
  if (!m) return "";
  const [y, mo] = m.split("-");
  return new Date(Number(y), Number(mo) - 1, 1).toLocaleDateString("en-US", { month: "short", year: "2-digit" });
}

function StatCard({ label, value, sub, icon: Icon, color = "blue", trend }: {
  label: string; value: string; sub?: string; icon: any; color?: string; trend?: number;
}) {
  const colors: Record<string, string> = {
    blue: "bg-blue-50 text-blue-600",
    green: "bg-green-50 text-green-600",
    orange: "bg-orange-50 text-orange-600",
    purple: "bg-purple-50 text-purple-600",
    red: "bg-red-50 text-red-600",
    teal: "bg-teal-50 text-teal-600",
  };
  return (
    <div className="bg-card border border-card-border rounded-lg p-4">
      <div className="flex items-start justify-between mb-2">
        <div className={`p-2 rounded-md ${colors[color]}`}>
          <Icon className="w-4 h-4" />
        </div>
        {trend !== undefined && (
          <span className={`text-xs font-medium flex items-center gap-0.5 ${trend >= 0 ? "text-green-600" : "text-red-500"}`}>
            {trend >= 0 ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
            {Math.abs(trend)}%
          </span>
        )}
      </div>
      <p className="text-2xl font-bold text-foreground mt-1">{value}</p>
      <p className="text-xs text-muted-foreground mt-0.5">{label}</p>
      {sub && <p className="text-xs text-muted-foreground/70 mt-0.5">{sub}</p>}
    </div>
  );
}

const GOAL_STORAGE_KEY = "crm_goals_v1";
const DEFAULT_GOALS = { revenueGoal: 2000000, mrrGoal: 150000 };

function useGoals() {
  const [goals, setGoals] = useState<{ revenueGoal: number; mrrGoal: number }>(() => {
    try {
      const stored = localStorage.getItem(GOAL_STORAGE_KEY);
      return stored ? JSON.parse(stored) : DEFAULT_GOALS;
    } catch {
      return DEFAULT_GOALS;
    }
  });

  const saveGoals = (next: { revenueGoal: number; mrrGoal: number }) => {
    setGoals(next);
    localStorage.setItem(GOAL_STORAGE_KEY, JSON.stringify(next));
  };

  return { goals, saveGoals };
}

function GoalBar({ label, value, goal, color, onEditGoal }: {
  label: string; value: number; goal: number; color: string; onEditGoal?: () => void;
}) {
  const percent = goal > 0 ? Math.round((value / goal) * 100) : 0;
  const capped = Math.min(percent, 100);
  const colorMap: Record<string, string> = {
    blue: "bg-blue-500", green: "bg-green-500", orange: "bg-orange-500",
  };
  return (
    <div className="mb-5">
      <div className="flex justify-between items-center text-sm mb-1.5">
        <span className="font-medium text-foreground">{label}</span>
        <div className="flex items-center gap-2">
          <span className="text-muted-foreground">{formatCurrency(value, true)} / {formatCurrency(goal, true)}</span>
          {onEditGoal && (
            <button
              onClick={onEditGoal}
              className="p-1 rounded hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
              title="Edit goal"
            >
              <Pencil className="w-3 h-3" />
            </button>
          )}
        </div>
      </div>
      <div className="h-3 bg-muted rounded-full overflow-hidden">
        <div
          className={`h-full rounded-full transition-all duration-500 ${colorMap[color]}`}
          style={{ width: `${capped}%` }}
        />
      </div>
      <div className="flex justify-between mt-1">
        <p className="text-xs text-muted-foreground">{percent}% of annual goal</p>
        {percent >= 100 && <p className="text-xs font-medium text-green-600">Goal achieved!</p>}
      </div>
    </div>
  );
}

function EditGoalModal({ label, currentGoal, onSave, onClose }: {
  label: string; currentGoal: number; onSave: (val: number) => void; onClose: () => void;
}) {
  const [raw, setRaw] = useState(String(currentGoal));
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => { inputRef.current?.focus(); inputRef.current?.select(); }, []);

  const handleSave = () => {
    const parsed = parseFloat(raw.replace(/[^0-9.]/g, ""));
    if (!isNaN(parsed) && parsed > 0) { onSave(parsed); onClose(); }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={onClose}>
      <div className="bg-card border border-card-border rounded-xl shadow-xl p-6 w-80" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-foreground">Edit {label}</h3>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground"><X className="w-4 h-4" /></button>
        </div>
        <label className="text-xs text-muted-foreground block mb-1">Annual Goal ($)</label>
        <input
          ref={inputRef}
          type="text"
          value={raw}
          onChange={(e) => setRaw(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter") handleSave(); if (e.key === "Escape") onClose(); }}
          className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 mb-4"
          placeholder="e.g. 2000000"
        />
        <div className="flex gap-2 justify-end">
          <button onClick={onClose} className="px-3 py-1.5 text-sm rounded-md border border-border text-muted-foreground hover:bg-muted transition-colors">Cancel</button>
          <button onClick={handleSave} className="px-3 py-1.5 text-sm rounded-md bg-primary text-primary-foreground hover:bg-primary/90 transition-colors flex items-center gap-1.5">
            <Check className="w-3.5 h-3.5" /> Save
          </button>
        </div>
      </div>
    </div>
  );
}

const STAGE_LABELS: Record<string, string> = {
  lead: "Lead", appointment_scheduled: "Appt Scheduled",
  demo_given: "Demo Given", contract_sent: "Contract Sent",
  closed_won: "Closed Won", closed_lost: "Closed Lost",
};

const COLORS = ["#3b82f6", "#8b5cf6", "#f59e0b", "#10b981", "#ef4444", "#06b6d4", "#f97316", "#ec4899"];
const REP_COLORS = ["#3b82f6", "#8b5cf6", "#f59e0b", "#10b981"];

export default function Analytics() {
  const { goals, saveGoals } = useGoals();
  const [editingGoal, setEditingGoal] = useState<"revenue" | "mrr" | null>(null);

  const closedWon = useQuery({ queryKey: ["analytics/closed-won"], queryFn: () => fetchJson("/api/analytics/closed-won") });
  const pipeline = useQuery({ queryKey: ["analytics/pipeline-report"], queryFn: () => fetchJson("/api/analytics/pipeline-report") });
  const callsByRep = useQuery({ queryKey: ["analytics/calls-by-rep"], queryFn: () => fetchJson("/api/analytics/calls-by-rep") });
  const callsTrend = useQuery({ queryKey: ["analytics/calls-trend"], queryFn: () => fetchJson("/api/analytics/calls-trend") });
  const meetingsByRep = useQuery({ queryKey: ["analytics/meetings-by-rep"], queryFn: () => fetchJson("/api/analytics/meetings-by-rep") });
  const meetingsTrend = useQuery({ queryKey: ["analytics/meetings-trend"], queryFn: () => fetchJson("/api/analytics/meetings-trend") });
  const wonLost = useQuery({ queryKey: ["analytics/deals-won-lost"], queryFn: () => fetchJson("/api/analytics/deals-won-lost") });
  const mrrPerf = useQuery({ queryKey: ["analytics/mrr-performance"], queryFn: () => fetchJson("/api/analytics/mrr-performance") });
  const avgMrr = useQuery({ queryKey: ["analytics/avg-mrr"], queryFn: () => fetchJson("/api/analytics/avg-mrr") });
  const aging = useQuery({ queryKey: ["analytics/deals-aging"], queryFn: () => fetchJson("/api/analytics/deals-aging") });
  const contactsWorked = useQuery({ queryKey: ["analytics/contacts-worked"], queryFn: () => fetchJson("/api/analytics/contacts-worked") });
  const bySource = useQuery({ queryKey: ["analytics/revenue-by-source"], queryFn: () => fetchJson("/api/analytics/revenue-by-source") });

  const cw = closedWon.data ?? {};
  const pl = (pipeline.data ?? []) as any[];
  const cbr = (callsByRep.data ?? []) as any[];
  const ct = (callsTrend.data ?? []) as any[];
  const mbr = (meetingsByRep.data ?? []) as any[];
  const mt = (meetingsTrend.data ?? []) as any[];
  const wl = (wonLost.data ?? []) as any[];
  const mp = (mrrPerf.data ?? []) as any[];
  const am = avgMrr.data ?? {};
  const ag = aging.data ?? { deals: [], buckets: [] };
  const cwd = contactsWorked.data ?? {};
  const src = (bySource.data ?? []) as any[];

  const totalCallsByRep = cbr.reduce((s: number, r: any) => s + r.totalCalls, 0);
  const totalConnectedByRep = cbr.reduce((s: number, r: any) => s + r.connectedCalls, 0);
  const totalMeetings = mbr.reduce((s: number, r: any) => s + r.totalMeetings, 0);

  return (
    <div className="p-6 space-y-8 max-w-7xl">
      {editingGoal === "revenue" && (
        <EditGoalModal
          label="Revenue Goal"
          currentGoal={goals.revenueGoal}
          onSave={(val) => saveGoals({ ...goals, revenueGoal: val })}
          onClose={() => setEditingGoal(null)}
        />
      )}
      {editingGoal === "mrr" && (
        <EditGoalModal
          label="MRR Goal"
          currentGoal={goals.mrrGoal}
          onSave={(val) => saveGoals({ ...goals, mrrGoal: val })}
          onClose={() => setEditingGoal(null)}
        />
      )}

      <div>
        <h1 className="text-2xl font-bold text-foreground">Analytics</h1>
        <p className="text-muted-foreground text-sm mt-1">Performance metrics and sales insights</p>
      </div>

      {/* ── Section 1: Closed Won Overview ──────────────────────────────────── */}
      <section>
        <h2 className="text-base font-semibold text-foreground mb-3 flex items-center gap-2">
          <Target className="w-4 h-4 text-green-500" /> Closed Won
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <StatCard icon={Briefcase} label="Total Deals Won" value={String(cw.count ?? 0)} color="green" />
          <StatCard icon={DollarSign} label="Total Revenue Won" value={formatCurrency(cw.totalValue, true)} color="green" />
          <StatCard icon={TrendingUp} label="Total MRR Won" value={formatCurrency(cw.totalMrr, true)} color="teal" />
          <StatCard icon={DollarSign} label="Avg Deal Size" value={formatCurrency(cw.avgDealSize, true)} color="blue" />
        </div>
      </section>

      {/* ── Section 2: Closed Won vs Goal ───────────────────────────────────── */}
      <section>
        <h2 className="text-base font-semibold text-foreground mb-3 flex items-center gap-2">
          <Zap className="w-4 h-4 text-orange-500" /> Closed Won vs Goal
        </h2>
        <div className="bg-card border border-card-border rounded-lg p-5">
          <GoalBar
            label="Revenue Goal"
            value={cw.totalValue ?? 0}
            goal={goals.revenueGoal}
            color="blue"
            onEditGoal={() => setEditingGoal("revenue")}
          />
          <GoalBar
            label="MRR Goal"
            value={cw.totalMrr ?? 0}
            goal={goals.mrrGoal}
            color="green"
            onEditGoal={() => setEditingGoal("mrr")}
          />
          <p className="text-xs text-muted-foreground">{cw.count ?? 0} deals closed won · Click the pencil icon to edit goals</p>
        </div>
      </section>

      {/* ── Section 3: Pipeline Report ───────────────────────────────────────── */}
      <section>
        <h2 className="text-base font-semibold text-foreground mb-3 flex items-center gap-2">
          <Briefcase className="w-4 h-4 text-blue-500" /> Pipeline Report
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-card border border-card-border rounded-lg p-5">
            <p className="text-sm font-medium text-muted-foreground mb-3">Deals by Stage</p>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={pl.map((s: any) => ({ ...s, label: STAGE_LABELS[s.stage] ?? s.stage }))}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="label" tick={{ fontSize: 10 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip formatter={(v: any) => [v, "Deals"]} />
                <Bar dataKey="count" fill="#3b82f6" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="bg-card border border-card-border rounded-lg p-5">
            <p className="text-sm font-medium text-muted-foreground mb-3">Pipeline Value by Stage</p>
            <div className="space-y-2 mt-2">
              {pl.map((s: any) => (
                <div key={s.stage} className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-blue-500 flex-shrink-0" />
                    <span className="text-foreground truncate max-w-[140px]">{STAGE_LABELS[s.stage] ?? s.stage}</span>
                    <span className="text-muted-foreground text-xs">({s.count})</span>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">{formatCurrency(s.totalValue, true)}</p>
                    <p className="text-xs text-muted-foreground">{s.avgProbability}% avg prob</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── Section 4: Calls ────────────────────────────────────────────────── */}
      <section>
        <h2 className="text-base font-semibold text-foreground mb-3 flex items-center gap-2">
          <Phone className="w-4 h-4 text-purple-500" /> Call Activity
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
          <StatCard icon={Phone} label="Total Calls Placed" value={String(totalCallsByRep)} color="purple" />
          <StatCard icon={Phone} label="Connected Calls" value={String(totalConnectedByRep)} color="blue" />
          <StatCard icon={TrendingUp} label="Avg Connection Rate"
            value={totalCallsByRep > 0 ? `${Math.round((totalConnectedByRep / totalCallsByRep) * 100)}%` : "0%"}
            color="green" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Calls by Rep */}
          <div className="bg-card border border-card-border rounded-lg p-5">
            <p className="text-sm font-medium text-muted-foreground mb-3">Total Calls by Rep</p>
            <div className="space-y-3">
              {cbr.map((r: any, i: number) => (
                <div key={r.rep}>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="font-medium text-foreground">{r.rep}</span>
                    <span className="text-muted-foreground">{r.totalCalls} calls</span>
                  </div>
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full"
                      style={{
                        width: `${totalCallsByRep > 0 ? (r.totalCalls / totalCallsByRep) * 100 : 0}%`,
                        backgroundColor: REP_COLORS[i % REP_COLORS.length],
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
          {/* Connected Calls by Rep */}
          <div className="bg-card border border-card-border rounded-lg p-5">
            <p className="text-sm font-medium text-muted-foreground mb-3">Connected Calls by Rep</p>
            <div className="space-y-3">
              {cbr.map((r: any, i: number) => (
                <div key={r.rep}>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="font-medium text-foreground">{r.rep}</span>
                    <span className="text-muted-foreground">{r.connectedCalls} connected ({r.connectionRate}%)</span>
                  </div>
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full"
                      style={{
                        width: `${r.connectionRate}%`,
                        backgroundColor: REP_COLORS[i % REP_COLORS.length],
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
        {/* Connected Calls Trend */}
        <div className="bg-card border border-card-border rounded-lg p-5 mt-4">
          <p className="text-sm font-medium text-muted-foreground mb-3">Connected Calls Trend (12 months)</p>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={ct.map((r: any) => ({ ...r, month: formatMonth(r.month) }))}>
              <defs>
                <linearGradient id="cgTotal" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="cgConnected" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="month" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip />
              <Legend />
              <Area type="monotone" dataKey="totalCalls" name="Total Calls" stroke="#8b5cf6" fill="url(#cgTotal)" strokeWidth={2} />
              <Area type="monotone" dataKey="connectedCalls" name="Connected" stroke="#3b82f6" fill="url(#cgConnected)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </section>

      {/* ── Section 5: Meetings ─────────────────────────────────────────────── */}
      <section>
        <h2 className="text-base font-semibold text-foreground mb-3 flex items-center gap-2">
          <Video className="w-4 h-4 text-teal-500" /> Meeting Activity
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
          <StatCard icon={Video} label="Total Meetings Completed" value={String(totalMeetings)} color="teal" />
          <StatCard icon={Clock} label="Avg Meeting Duration" value={`${Math.round(mbr.reduce((s: number, r: any) => s + r.avgDuration, 0) / Math.max(mbr.length, 1))} min`} color="orange" />
          <StatCard icon={Users} label="Active Reps" value={String(mbr.length)} color="blue" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Meetings by Rep */}
          <div className="bg-card border border-card-border rounded-lg p-5">
            <p className="text-sm font-medium text-muted-foreground mb-3">Meetings Completed by Rep</p>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={mbr} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis type="number" tick={{ fontSize: 11 }} />
                <YAxis dataKey="rep" type="category" tick={{ fontSize: 11 }} width={90} />
                <Tooltip formatter={(v: any) => [v, "Meetings"]} />
                <Bar dataKey="totalMeetings" fill="#14b8a6" radius={[0, 3, 3, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          {/* Meetings Trend */}
          <div className="bg-card border border-card-border rounded-lg p-5">
            <p className="text-sm font-medium text-muted-foreground mb-3">Meetings Completed Trend</p>
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={mt.map((r: any) => ({ ...r, month: formatMonth(r.month) }))}>
                <defs>
                  <linearGradient id="mgMeetings" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#14b8a6" stopOpacity={0.15} />
                    <stop offset="95%" stopColor="#14b8a6" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="month" tick={{ fontSize: 10 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip />
                <Area type="monotone" dataKey="totalMeetings" name="Meetings" stroke="#14b8a6" fill="url(#mgMeetings)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </section>

      {/* ── Section 6: Won vs Lost ──────────────────────────────────────────── */}
      <section>
        <h2 className="text-base font-semibold text-foreground mb-3 flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-green-500" /> Deals Won vs Lost
        </h2>
        <div className="bg-card border border-card-border rounded-lg p-5">
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={wl.map((r: any) => ({ ...r, month: formatMonth(r.month) }))}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="month" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip />
              <Legend />
              <Bar dataKey="wonCount" name="Won" fill="#10b981" radius={[3, 3, 0, 0]} />
              <Bar dataKey="lostCount" name="Lost" fill="#ef4444" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </section>

      {/* ── Section 7: MRR Performance ─────────────────────────────────────── */}
      <section>
        <h2 className="text-base font-semibold text-foreground mb-3 flex items-center gap-2">
          <DollarSign className="w-4 h-4 text-blue-500" /> MRR Performance
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-card border border-card-border rounded-lg p-5">
            <p className="text-sm font-medium text-muted-foreground mb-3">MRR Closed Won (Monthly)</p>
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={mp.map((r: any) => ({ ...r, month: formatMonth(r.month) }))}>
                <defs>
                  <linearGradient id="mrrGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.15} />
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="month" tick={{ fontSize: 10 }} />
                <YAxis tick={{ fontSize: 11 }} tickFormatter={(v) => `$${(v / 1000).toFixed(0)}K`} />
                <Tooltip formatter={(v: any) => [formatCurrency(v), "MRR"]} />
                <Area type="monotone" dataKey="totalMrr" name="MRR" stroke="#3b82f6" fill="url(#mrrGrad)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          {/* Average MRR Deal Size by Rep */}
          <div className="bg-card border border-card-border rounded-lg p-5">
            <p className="text-sm font-medium text-muted-foreground mb-3">Average MRR Deal Size by Rep</p>
            <div className="mb-3 p-3 bg-muted/30 rounded-md">
              <p className="text-xs text-muted-foreground">Overall Average MRR</p>
              <p className="text-lg font-bold text-foreground">{formatCurrency(am.overallAvgMrr)}</p>
              <p className="text-xs text-muted-foreground">Avg deal size: {formatCurrency(am.overallAvgDealSize)}</p>
            </div>
            <div className="space-y-2">
              {(am.byRep ?? []).map((r: any, i: number) => (
                <div key={r.rep} className="flex items-center justify-between text-sm py-1.5 border-b border-border/40 last:border-0">
                  <span className="font-medium text-foreground">{r.rep}</span>
                  <div className="text-right">
                    <p className="font-semibold text-foreground">{formatCurrency(r.avgMrr)}</p>
                    <p className="text-xs text-muted-foreground">{r.wonCount} deals won</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── Section 8: Deals Aging ─────────────────────────────────────────── */}
      <section>
        <h2 className="text-base font-semibold text-foreground mb-3 flex items-center gap-2">
          <Clock className="w-4 h-4 text-orange-500" /> Deals Aging Report
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-card border border-card-border rounded-lg p-5">
            <p className="text-sm font-medium text-muted-foreground mb-3">Open Deals by Age</p>
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={ag.buckets}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="bucket" tick={{ fontSize: 10 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip formatter={(v: any) => [v, "Deals"]} />
                <Bar dataKey="count" fill="#f59e0b" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="bg-card border border-card-border rounded-lg p-5 overflow-auto max-h-72">
            <p className="text-sm font-medium text-muted-foreground mb-3">Oldest Open Deals</p>
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-border text-muted-foreground">
                  <th className="text-left pb-2 font-medium">Deal</th>
                  <th className="text-left pb-2 font-medium">Rep</th>
                  <th className="text-right pb-2 font-medium">Days</th>
                  <th className="text-right pb-2 font-medium">Value</th>
                </tr>
              </thead>
              <tbody>
                {ag.deals.slice(0, 8).map((d: any) => (
                  <tr key={d.id} className="border-b border-border/40 last:border-0">
                    <td className="py-1.5 text-foreground truncate max-w-[120px]">{d.title}</td>
                    <td className="py-1.5 text-muted-foreground">{d.assignedTo ?? "-"}</td>
                    <td className="py-1.5 text-right font-semibold text-orange-500">{d.daysOpen}d</td>
                    <td className="py-1.5 text-right font-medium">{formatCurrency(d.totalValue, true)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* ── Section 9: Contacts & Deals Created / Worked / Won ─────────────── */}
      <section>
        <h2 className="text-base font-semibold text-foreground mb-3 flex items-center gap-2">
          <Users className="w-4 h-4 text-blue-500" /> Contacts & Deals Activity
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
          <StatCard icon={Users} label="Total Contacts" value={String(cwd.totalContacts ?? 0)} color="blue" />
          <StatCard icon={Users} label="Contacts Worked" value={String(cwd.contactsWorked ?? 0)}
            sub={`of ${cwd.totalContacts ?? 0} total`} color="purple" />
          <StatCard icon={Briefcase} label="Total Deals Created" value={String(cwd.totalDeals ?? 0)} color="orange" />
          <StatCard icon={Target} label="Total Deals Won" value={String(cwd.dealsWonTotal ?? 0)}
            sub={`${cwd.totalDeals > 0 ? Math.round((cwd.dealsWonTotal / cwd.totalDeals) * 100) : 0}% win rate`} color="green" />
        </div>
        <div className="bg-card border border-card-border rounded-lg p-5">
          <p className="text-sm font-medium text-muted-foreground mb-3">Contacts Created vs Deals Created & Won (Monthly)</p>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={(cwd.monthlyTrend ?? []).map((r: any) => ({ ...r, month: formatMonth(r.month) }))}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="month" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip />
              <Legend />
              <Bar dataKey="contactsCreated" name="Contacts Created" fill="#3b82f6" radius={[3, 3, 0, 0]} />
              <Bar dataKey="dealsCreated" name="Deals Created" fill="#f59e0b" radius={[3, 3, 0, 0]} />
              <Bar dataKey="dealsWon" name="Deals Won" fill="#10b981" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </section>

      {/* ── Section 10: Revenue by Source ───────────────────────────────────── */}
      <section>
        <h2 className="text-base font-semibold text-foreground mb-3 flex items-center gap-2">
          <DollarSign className="w-4 h-4 text-green-500" /> Revenue by Source
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-card border border-card-border rounded-lg p-5">
            <p className="text-sm font-medium text-muted-foreground mb-3">Won Revenue by Source</p>
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie
                  data={src.filter((s: any) => s.wonValue > 0)}
                  dataKey="wonValue"
                  nameKey="source"
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  label={({ source, percent }: any) => `${source} ${(percent * 100).toFixed(0)}%`}
                  labelLine={true}
                >
                  {src.filter((s: any) => s.wonValue > 0).map((_: any, i: number) => (
                    <Cell key={i} fill={COLORS[i % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(v: any) => [formatCurrency(v), "Revenue"]} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="bg-card border border-card-border rounded-lg p-5">
            <p className="text-sm font-medium text-muted-foreground mb-3">Performance by Source</p>
            <div className="overflow-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border text-muted-foreground text-xs">
                    <th className="text-left pb-2 font-medium">Source</th>
                    <th className="text-right pb-2 font-medium">Deals</th>
                    <th className="text-right pb-2 font-medium">Won</th>
                    <th className="text-right pb-2 font-medium">Win %</th>
                    <th className="text-right pb-2 font-medium">Revenue</th>
                    <th className="text-right pb-2 font-medium">MRR</th>
                  </tr>
                </thead>
                <tbody>
                  {src.map((s: any, i: number) => (
                    <tr key={s.source} className="border-b border-border/40 last:border-0">
                      <td className="py-2 flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
                        {s.source}
                      </td>
                      <td className="py-2 text-right text-muted-foreground">{s.count}</td>
                      <td className="py-2 text-right text-muted-foreground">{s.wonCount}</td>
                      <td className="py-2 text-right">
                        <span className={`font-medium ${s.winRate >= 50 ? "text-green-600" : s.winRate >= 30 ? "text-orange-500" : "text-red-500"}`}>
                          {s.winRate}%
                        </span>
                      </td>
                      <td className="py-2 text-right font-medium">{formatCurrency(s.wonValue, true)}</td>
                      <td className="py-2 text-right text-teal-600 font-medium">{formatCurrency(s.totalMrr, true)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
