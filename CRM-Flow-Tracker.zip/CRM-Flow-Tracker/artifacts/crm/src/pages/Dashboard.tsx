import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { useGetDashboardSummary, useGetRecentActivity } from "@workspace/api-client-react";
import { formatCurrency, formatDateTime, STAGES } from "@/lib/utils";
import StageBadge from "@/components/StageBadge";
import ActivityBadge from "@/components/ActivityBadge";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell,
} from "recharts";
import {
  Briefcase, Users, Building2, TrendingUp, DollarSign, CheckCircle,
  CalendarDays, X, ExternalLink,
} from "lucide-react";
import { Link } from "wouter";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

const STAGE_BAR_COLORS: Record<string, string> = {
  lead: "#3b82f6",
  appointment_scheduled: "#a855f7",
  demo_given: "#f59e0b",
  contract_sent: "#f97316",
  closed_won: "#22c55e",
  closed_lost: "#ef4444",
};

const CURRENT_YEAR = new Date().getFullYear();
const YEARS = Array.from({ length: 5 }, (_, i) => CURRENT_YEAR - 2 + i);
const MONTHS = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
];

type FilterMode = "all" | "year" | "month" | "range";

interface FilterState {
  mode: FilterMode;
  year: number;
  month: number;
  startDate: string;
  endDate: string;
}

function computeDateRange(f: FilterState): { startDate?: string; endDate?: string } {
  if (f.mode === "all") return {};
  if (f.mode === "year") return { startDate: `${f.year}-01-01`, endDate: `${f.year}-12-31` };
  if (f.mode === "month") {
    const lastDay = new Date(f.year, f.month + 1, 0).getDate();
    const mm = String(f.month + 1).padStart(2, "0");
    return { startDate: `${f.year}-${mm}-01`, endDate: `${f.year}-${mm}-${String(lastDay).padStart(2, "0")}` };
  }
  if (f.mode === "range") {
    return { startDate: f.startDate || undefined, endDate: f.endDate || undefined };
  }
  return {};
}

function buildFilterLabel(f: FilterState): string {
  if (f.mode === "all") return "All time";
  if (f.mode === "year") return String(f.year);
  if (f.mode === "month") return `${MONTHS[f.month]} ${f.year}`;
  if (f.mode === "range") {
    if (f.startDate && f.endDate) return `${f.startDate} → ${f.endDate}`;
    if (f.startDate) return `From ${f.startDate}`;
    if (f.endDate) return `Until ${f.endDate}`;
    return "Custom range";
  }
  return "";
}

function usePipeline(startDate?: string, endDate?: string) {
  const params = new URLSearchParams();
  if (startDate) params.set("startDate", startDate);
  if (endDate) params.set("endDate", endDate);
  const qs = params.toString();
  return useQuery({
    queryKey: ["dashboard/pipeline", startDate, endDate],
    queryFn: () => fetch(`${BASE}/api/dashboard/pipeline${qs ? `?${qs}` : ""}`).then((r) => r.json()),
  });
}

function useStageDeals(stage: string | null, startDate?: string, endDate?: string) {
  const params = new URLSearchParams();
  if (stage) params.set("stage", stage);
  if (startDate) params.set("startDate", startDate);
  if (endDate) params.set("endDate", endDate);
  return useQuery({
    queryKey: ["dashboard/stage-deals", stage, startDate, endDate],
    queryFn: () => fetch(`${BASE}/api/dashboard/stage-deals?${params.toString()}`).then((r) => r.json()),
    enabled: !!stage,
  });
}

// Custom bar tooltip
function CustomTooltip({ active, payload }: any) {
  if (!active || !payload?.length) return null;
  const d = payload[0].payload;
  return (
    <div className="bg-popover border border-border rounded-lg shadow-lg p-3 text-xs min-w-[160px]">
      <p className="font-semibold text-foreground mb-1.5">
        {STAGES.find((s) => s.key === d.stage)?.label ?? d.stage}
      </p>
      <div className="space-y-1 text-muted-foreground">
        <div className="flex justify-between gap-4">
          <span>Deals</span>
          <span className="font-medium text-foreground">{d.count}</span>
        </div>
        <div className="flex justify-between gap-4">
          <span>Total value</span>
          <span className="font-medium text-foreground">{formatCurrency(d.value)}</span>
        </div>
        <div className="border-t border-border/60 pt-1 mt-1">
          <div className="flex justify-between gap-4">
            <span>Capex</span>
            <span>{formatCurrency(d.capex)}</span>
          </div>
          <div className="flex justify-between gap-4">
            <span>Opex</span>
            <span>{formatCurrency(d.opex)}</span>
          </div>
        </div>
      </div>
      <p className="mt-2 text-[10px] text-muted-foreground italic">Click bar to see deals</p>
    </div>
  );
}

// Stage deals modal
function StageDealsModal({
  stage,
  startDate,
  endDate,
  filterLabel,
  onClose,
}: {
  stage: string;
  startDate?: string;
  endDate?: string;
  filterLabel: string;
  onClose: () => void;
}) {
  const { data: deals = [], isLoading } = useStageDeals(stage, startDate, endDate);
  const stageInfo = STAGES.find((s) => s.key === stage);
  const total = deals.reduce((sum: number, d: any) => sum + (d.totalValue ?? 0), 0);
  const totalCapex = deals.reduce((sum: number, d: any) => sum + (d.capex ?? 0), 0);
  const totalOpex = deals.reduce((sum: number, d: any) => sum + (d.opex ?? 0), 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={onClose} />

      {/* Modal */}
      <div className="relative bg-card border border-card-border rounded-xl shadow-2xl w-full max-w-2xl max-h-[80vh] flex flex-col">
        {/* Header */}
        <div className="flex items-start justify-between p-5 border-b border-border/60">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <StageBadge stage={stage} />
              <span className="text-sm text-muted-foreground">
                {deals.length} deal{deals.length !== 1 ? "s" : ""}
              </span>
            </div>
            {filterLabel !== "All time" && (
              <p className="text-xs text-muted-foreground flex items-center gap-1">
                <CalendarDays className="w-3 h-3" /> {filterLabel}
              </p>
            )}
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-md hover:bg-muted text-muted-foreground hover:text-foreground transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Summary row */}
        <div className="grid grid-cols-3 gap-px bg-border/40 border-b border-border/60">
          {[
            { label: "Total Value", value: total },
            { label: "Total Capex", value: totalCapex },
            { label: "Total Opex", value: totalOpex },
          ].map(({ label, value }) => (
            <div key={label} className="bg-card px-4 py-3 text-center">
              <div className="text-xs text-muted-foreground">{label}</div>
              <div className="text-sm font-semibold text-foreground mt-0.5">{formatCurrency(value)}</div>
            </div>
          ))}
        </div>

        {/* Deals list */}
        <div className="overflow-y-auto flex-1">
          {isLoading ? (
            <div className="flex items-center justify-center h-32 text-sm text-muted-foreground">Loading...</div>
          ) : deals.length === 0 ? (
            <div className="flex items-center justify-center h-32 text-sm text-muted-foreground">
              No deals in this stage for the selected period
            </div>
          ) : (
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border/60 bg-muted/40 text-xs text-muted-foreground">
                  <th className="text-left px-5 py-2.5 font-medium">Deal</th>
                  <th className="text-left px-3 py-2.5 font-medium">Contact / Company</th>
                  <th className="text-right px-3 py-2.5 font-medium">Capex</th>
                  <th className="text-right px-3 py-2.5 font-medium">Opex</th>
                  <th className="text-right px-5 py-2.5 font-medium">Total</th>
                </tr>
              </thead>
              <tbody>
                {deals.map((deal: any) => (
                  <tr key={deal.id} className="border-b border-border/40 last:border-0 hover:bg-muted/30 transition-colors">
                    <td className="px-5 py-3">
                      <Link
                        to={`/deals/${deal.id}`}
                        className="font-medium text-foreground hover:text-primary flex items-center gap-1 group"
                        onClick={onClose}
                      >
                        {deal.title}
                        <ExternalLink className="w-3 h-3 opacity-0 group-hover:opacity-60 transition-opacity" />
                      </Link>
                      {deal.assignedTo && (
                        <div className="text-xs text-muted-foreground mt-0.5">{deal.assignedTo}</div>
                      )}
                    </td>
                    <td className="px-3 py-3">
                      <div className="text-foreground truncate max-w-[140px]">
                        {deal.contactName ?? deal.companyName ?? "—"}
                      </div>
                      {deal.contactName && deal.companyName && (
                        <div className="text-xs text-muted-foreground truncate max-w-[140px]">{deal.companyName}</div>
                      )}
                    </td>
                    <td className="px-3 py-3 text-right tabular-nums">{formatCurrency(deal.capex)}</td>
                    <td className="px-3 py-3 text-right tabular-nums">{formatCurrency(deal.opex)}</td>
                    <td className="px-5 py-3 text-right font-semibold tabular-nums text-foreground">
                      {formatCurrency(deal.totalValue)}
                    </td>
                  </tr>
                ))}
              </tbody>
              {/* Totals row */}
              <tfoot>
                <tr className="bg-muted/40 border-t border-border text-xs font-semibold text-foreground">
                  <td className="px-5 py-2.5" colSpan={2}>Totals</td>
                  <td className="px-3 py-2.5 text-right tabular-nums">{formatCurrency(totalCapex)}</td>
                  <td className="px-3 py-2.5 text-right tabular-nums">{formatCurrency(totalOpex)}</td>
                  <td className="px-5 py-2.5 text-right tabular-nums">{formatCurrency(total)}</td>
                </tr>
              </tfoot>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}

export default function Dashboard() {
  const [filter, setFilter] = useState<FilterState>({
    mode: "all",
    year: CURRENT_YEAR,
    month: new Date().getMonth(),
    startDate: "",
    endDate: "",
  });
  const [selectedStage, setSelectedStage] = useState<string | null>(null);

  const { startDate, endDate } = useMemo(() => computeDateRange(filter), [filter]);
  const filterLabel = useMemo(() => buildFilterLabel(filter), [filter]);

  const { data: summary } = useGetDashboardSummary();
  const { data: pipeline = [] } = usePipeline(startDate, endDate);
  const { data: recentActivity } = useGetRecentActivity({ limit: 8 });

  const chartData = pipeline.map((p: any) => ({
    name: STAGES.find((s) => s.key === p.stage)?.label.split(" ")[0] ?? p.stage,
    stage: p.stage,
    value: p.totalValue,
    capex: p.totalCapex,
    opex: p.totalOpex,
    count: p.count,
  }));

  const statCards = [
    { label: "Total Deals", value: summary?.totalDeals ?? 0, icon: Briefcase, color: "text-blue-600 bg-blue-50" },
    { label: "Total Contacts", value: summary?.totalContacts ?? 0, icon: Users, color: "text-purple-600 bg-purple-50" },
    { label: "Companies", value: summary?.totalCompanies ?? 0, icon: Building2, color: "text-amber-600 bg-amber-50" },
    { label: "Open Pipeline", value: formatCurrency(summary?.totalPipelineValue), icon: TrendingUp, color: "text-indigo-600 bg-indigo-50" },
    { label: "Won Revenue", value: formatCurrency(summary?.wonValue), icon: CheckCircle, color: "text-green-600 bg-green-50" },
    { label: "Total Capex", value: formatCurrency(summary?.totalCapex), icon: DollarSign, color: "text-orange-600 bg-orange-50" },
  ];

  const setMode = (mode: FilterMode) => setFilter((f) => ({ ...f, mode }));

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Dashboard</h1>
        <p className="text-sm text-muted-foreground mt-0.5">Your pipeline at a glance</p>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {statCards.map((card) => {
          const Icon = card.icon;
          return (
            <div key={card.label} className="bg-card border border-card-border rounded-lg p-4">
              <div className={`w-8 h-8 rounded-md flex items-center justify-center mb-3 ${card.color}`}>
                <Icon className="w-4 h-4" />
              </div>
              <div className="text-xl font-bold text-foreground">{card.value}</div>
              <div className="text-xs text-muted-foreground mt-0.5">{card.label}</div>
            </div>
          );
        })}
      </div>

      {/* Unified Pipeline card */}
      <div className="bg-card border border-card-border rounded-lg p-5">
        {/* Header row */}
        <div className="flex flex-wrap items-start justify-between gap-3 mb-4">
          <div>
            <h2 className="font-semibold text-foreground">Pipeline Value by Stage</h2>
            {filter.mode !== "all" && (
              <p className="text-xs text-muted-foreground mt-0.5 flex items-center gap-1">
                <CalendarDays className="w-3 h-3" />
                {filterLabel}
                <button
                  onClick={() => setMode("all")}
                  className="ml-1 text-muted-foreground hover:text-foreground"
                  title="Clear filter"
                >
                  <X className="w-3 h-3" />
                </button>
              </p>
            )}
          </div>
          {/* Mode tabs */}
          <div className="flex items-center gap-1 bg-muted rounded-lg p-0.5 text-xs font-medium">
            {(["all", "year", "month", "range"] as FilterMode[]).map((m) => (
              <button
                key={m}
                onClick={() => setMode(m)}
                className={`px-2.5 py-1 rounded-md capitalize transition-colors ${
                  filter.mode === m
                    ? "bg-card text-foreground shadow-sm"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {m === "all" ? "All" : m === "range" ? "Range" : m.charAt(0).toUpperCase() + m.slice(1)}
              </button>
            ))}
          </div>
        </div>

        {/* Filter controls */}
        {filter.mode === "year" && (
          <div className="flex items-center gap-2 mb-4">
            <label className="text-xs text-muted-foreground font-medium">Year</label>
            <select
              value={filter.year}
              onChange={(e) => setFilter((f) => ({ ...f, year: Number(e.target.value) }))}
              className="text-sm border border-input rounded-md px-2 py-1 bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary/40"
            >
              {YEARS.map((y) => <option key={y} value={y}>{y}</option>)}
            </select>
          </div>
        )}
        {filter.mode === "month" && (
          <div className="flex items-center gap-2 mb-4 flex-wrap">
            <label className="text-xs text-muted-foreground font-medium">Month</label>
            <select
              value={filter.month}
              onChange={(e) => setFilter((f) => ({ ...f, month: Number(e.target.value) }))}
              className="text-sm border border-input rounded-md px-2 py-1 bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary/40"
            >
              {MONTHS.map((m, i) => <option key={m} value={i}>{m}</option>)}
            </select>
            <select
              value={filter.year}
              onChange={(e) => setFilter((f) => ({ ...f, year: Number(e.target.value) }))}
              className="text-sm border border-input rounded-md px-2 py-1 bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary/40"
            >
              {YEARS.map((y) => <option key={y} value={y}>{y}</option>)}
            </select>
          </div>
        )}
        {filter.mode === "range" && (
          <div className="flex items-center gap-2 mb-4 flex-wrap">
            <label className="text-xs text-muted-foreground font-medium">From</label>
            <input
              type="date"
              value={filter.startDate}
              onChange={(e) => setFilter((f) => ({ ...f, startDate: e.target.value }))}
              className="text-sm border border-input rounded-md px-2 py-1 bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary/40"
            />
            <label className="text-xs text-muted-foreground font-medium">To</label>
            <input
              type="date"
              value={filter.endDate}
              onChange={(e) => setFilter((f) => ({ ...f, endDate: e.target.value }))}
              className="text-sm border border-input rounded-md px-2 py-1 bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary/40"
            />
          </div>
        )}

        {/* Chart */}
        <div className="mb-6">
          {chartData.some((d: any) => d.value > 0) ? (
            <ResponsiveContainer width="100%" height={200}>
              <BarChart
                data={chartData}
                margin={{ top: 4, right: 4, bottom: 0, left: 0 }}
                onClick={(e) => {
                  if (e?.activePayload?.[0]?.payload?.stage) {
                    setSelectedStage(e.activePayload[0].payload.stage);
                  }
                }}
                style={{ cursor: "pointer" }}
              >
                <XAxis dataKey="name" tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis
                  tick={{ fontSize: 11 }}
                  axisLine={false}
                  tickLine={false}
                  tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`}
                />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                  {chartData.map((entry: any) => (
                    <Cell key={entry.stage} fill={STAGE_BAR_COLORS[entry.stage] ?? "#94a3b8"} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[200px] flex items-center justify-center text-muted-foreground text-sm">
              No deals found for {filterLabel}
            </div>
          )}
        </div>

        {/* Stage breakdown table (merged) */}
        <div className="border-t border-border/60 pt-4">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-3">Stage Breakdown</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
            {pipeline.map((p: any) => {
              const stageMeta = STAGES.find((s) => s.key === p.stage);
              const color = STAGE_BAR_COLORS[p.stage] ?? "#94a3b8";
              return (
                <button
                  key={p.stage}
                  onClick={() => setSelectedStage(p.stage)}
                  className="flex items-center justify-between rounded-lg border border-border/60 px-4 py-3 hover:bg-muted/50 hover:border-border transition-colors text-left group"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ backgroundColor: color }} />
                    <div className="min-w-0">
                      <div className="text-sm font-medium text-foreground truncate">{stageMeta?.label ?? p.stage}</div>
                      <div className="text-xs text-muted-foreground">{p.count} deal{p.count !== 1 ? "s" : ""}</div>
                    </div>
                  </div>
                  <div className="text-right flex-shrink-0 ml-3">
                    <div className="text-sm font-semibold text-foreground">{formatCurrency(p.totalValue)}</div>
                    <div className="text-xs text-muted-foreground">
                      C: {formatCurrency(p.totalCapex)} / O: {formatCurrency(p.totalOpex)}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Recent activity */}
      <div className="bg-card border border-card-border rounded-lg p-5">
        <h2 className="font-semibold text-foreground mb-4">Recent Activity</h2>
        {(recentActivity ?? []).length === 0 ? (
          <p className="text-sm text-muted-foreground">No activity yet</p>
        ) : (
          <div className="space-y-3">
            {(recentActivity ?? []).map((a) => (
              <div key={a.id} className="flex items-start gap-3 py-2 border-b border-border/60 last:border-0">
                <ActivityBadge type={a.type} />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">{a.title}</p>
                  <p className="text-xs text-muted-foreground">
                    {a.dealTitle && <span className="mr-2">{a.dealTitle}</span>}
                    {a.contactName && <span>{a.contactName}</span>}
                  </p>
                </div>
                <span className="text-xs text-muted-foreground flex-shrink-0">{formatDateTime(a.createdAt)}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Stage deals modal */}
      {selectedStage && (
        <StageDealsModal
          stage={selectedStage}
          startDate={startDate}
          endDate={endDate}
          filterLabel={filterLabel}
          onClose={() => setSelectedStage(null)}
        />
      )}
    </div>
  );
}
