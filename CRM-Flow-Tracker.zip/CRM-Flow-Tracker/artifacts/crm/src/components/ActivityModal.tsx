import { useForm } from "react-hook-form";
import { useCreateActivity } from "@workspace/api-client-react";
import { X } from "lucide-react";

interface Props {
  dealId?: number;
  contactId?: number;
  defaultType?: string;
  onClose: () => void;
  onSuccess: () => void;
}

export default function ActivityModal({ dealId, contactId, defaultType = "note", onClose, onSuccess }: Props) {
  const { register, handleSubmit, formState: { errors } } = useForm({
    defaultValues: { type: defaultType, title: "", content: "", scheduledAt: "", duration: "", outcome: "" },
  });
  const createActivity = useCreateActivity();

  const onSubmit = (data: Record<string, string>) => {
    createActivity.mutate({
      data: {
        type: data.type as "note" | "meeting" | "call",
        title: data.title,
        content: data.content || null,
        scheduledAt: data.scheduledAt || null,
        duration: data.duration ? parseInt(data.duration) : null,
        outcome: data.outcome || null,
        dealId: dealId ?? null,
        contactId: contactId ?? null,
      },
    }, { onSuccess });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="bg-card border border-card-border rounded-xl shadow-xl w-full max-w-md">
        <div className="flex items-center justify-between p-5 border-b border-border">
          <h2 className="font-semibold text-foreground">Log Activity</h2>
          <button onClick={onClose} className="p-1 rounded hover:bg-muted"><X className="w-4 h-4" /></button>
        </div>
        <form onSubmit={handleSubmit(onSubmit)} className="p-5 space-y-4">
          <div className="grid grid-cols-3 gap-2">
            {["note", "meeting", "call"].map((t) => (
              <label key={t} className="flex items-center justify-center gap-1.5 border border-input rounded-md px-3 py-2 text-sm cursor-pointer has-[:checked]:bg-primary has-[:checked]:text-primary-foreground has-[:checked]:border-primary transition-colors capitalize">
                <input type="radio" value={t} {...register("type")} className="sr-only" />
                {t}
              </label>
            ))}
          </div>
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1">Title *</label>
            <input {...register("title", { required: true })} className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" placeholder="Activity title" />
            {errors.title && <p className="text-xs text-destructive mt-1">Title is required</p>}
          </div>
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1">Notes / Content</label>
            <textarea {...register("content")} rows={3} className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring resize-none" placeholder="Details..." />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1">Date & Time</label>
              <input {...register("scheduledAt")} type="datetime-local" className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" />
            </div>
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1">Duration (min)</label>
              <input {...register("duration")} type="number" min="0" className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" placeholder="30" />
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1">Outcome</label>
            <input {...register("outcome")} className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" placeholder="What was the result?" />
          </div>
          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="flex-1 px-4 py-2 border border-border rounded-md text-sm font-medium hover:bg-muted transition-colors">Cancel</button>
            <button type="submit" disabled={createActivity.isPending} className="flex-1 px-4 py-2 bg-primary text-primary-foreground rounded-md text-sm font-medium hover:opacity-90 disabled:opacity-50 transition-opacity">
              {createActivity.isPending ? "Saving..." : "Save Activity"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
