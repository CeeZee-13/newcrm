import { cn } from "@/lib/utils";
import { FileText, Users, Phone } from "lucide-react";

const icons = { note: FileText, meeting: Users, call: Phone };
const colors = {
  note: "bg-slate-100 text-slate-700",
  meeting: "bg-indigo-100 text-indigo-700",
  call: "bg-emerald-100 text-emerald-700",
};

export default function ActivityBadge({ type, className }: { type: string; className?: string }) {
  const Icon = icons[type as keyof typeof icons] ?? FileText;
  return (
    <span className={cn("inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium capitalize", colors[type as keyof typeof colors] ?? "bg-gray-100 text-gray-700", className)}>
      <Icon className="w-3 h-3" />
      {type}
    </span>
  );
}
