import { useForm } from "react-hook-form";
import { useCreateDeal, useListContacts, useListCompanies } from "@workspace/api-client-react";
import { STAGES } from "@/lib/utils";
import { X } from "lucide-react";

interface Props {
  defaultStage?: string;
  onClose: () => void;
  onSuccess: () => void;
}

export default function NewDealModal({ defaultStage = "lead", onClose, onSuccess }: Props) {
  const { register, handleSubmit, formState: { errors } } = useForm({
    defaultValues: { title: "", stage: defaultStage, capex: "", opex: "", currency: "USD", probability: "", description: "", contactId: "", companyId: "" },
  });
  const createDeal = useCreateDeal();
  const { data: contacts = [] } = useListContacts();
  const { data: companies = [] } = useListCompanies();

  const onSubmit = (data: Record<string, string>) => {
    createDeal.mutate({
      data: {
        title: data.title,
        stage: data.stage,
        capex: data.capex ? parseFloat(data.capex) : null,
        opex: data.opex ? parseFloat(data.opex) : null,
        currency: data.currency || "USD",
        probability: data.probability ? parseInt(data.probability) : null,
        description: data.description || null,
        contactId: data.contactId ? parseInt(data.contactId) : null,
        companyId: data.companyId ? parseInt(data.companyId) : null,
      },
    }, { onSuccess });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="bg-card border border-card-border rounded-xl shadow-xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-5 border-b border-border">
          <h2 className="font-semibold text-foreground">New Deal</h2>
          <button onClick={onClose} className="p-1 rounded hover:bg-muted"><X className="w-4 h-4" /></button>
        </div>
        <form onSubmit={handleSubmit(onSubmit)} className="p-5 space-y-4">
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1">Deal Title *</label>
            <input {...register("title", { required: true })} className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" placeholder="e.g. Acme Corp Platform Deal" />
            {errors.title && <p className="text-xs text-destructive mt-1">Title is required</p>}
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1">Stage</label>
              <select {...register("stage")} className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring">
                {STAGES.map((s) => <option key={s.key} value={s.key}>{s.label}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1">Probability (%)</label>
              <input {...register("probability")} type="number" min="0" max="100" className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" placeholder="0–100" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1">Capex</label>
              <input {...register("capex")} type="number" step="0.01" className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" placeholder="0.00" />
            </div>
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1">Opex</label>
              <input {...register("opex")} type="number" step="0.01" className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring" placeholder="0.00" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1">Contact</label>
              <select {...register("contactId")} className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring">
                <option value="">No contact</option>
                {contacts.map((c) => <option key={c.id} value={c.id}>{c.firstName} {c.lastName}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1">Company</label>
              <select {...register("companyId")} className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring">
                <option value="">No company</option>
                {companies.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-muted-foreground mb-1">Description</label>
            <textarea {...register("description")} rows={2} className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background focus:outline-none focus:ring-2 focus:ring-ring resize-none" placeholder="Optional description..." />
          </div>
          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="flex-1 px-4 py-2 border border-border rounded-md text-sm font-medium hover:bg-muted transition-colors">Cancel</button>
            <button type="submit" disabled={createDeal.isPending} className="flex-1 px-4 py-2 bg-primary text-primary-foreground rounded-md text-sm font-medium hover:opacity-90 disabled:opacity-50 transition-opacity">
              {createDeal.isPending ? "Creating..." : "Create Deal"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
