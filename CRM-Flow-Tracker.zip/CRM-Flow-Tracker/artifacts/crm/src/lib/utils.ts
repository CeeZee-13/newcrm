import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatCurrency(value: number | null | undefined, currency = "USD"): string {
  if (value == null) return "-";
  return new Intl.NumberFormat("en-US", { style: "currency", currency, maximumFractionDigits: 0 }).format(value);
}

export function formatDate(dateStr: string | null | undefined): string {
  if (!dateStr) return "-";
  return new Date(dateStr).toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" });
}

export function formatDateTime(dateStr: string | null | undefined): string {
  if (!dateStr) return "-";
  return new Date(dateStr).toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}

export const STAGES = [
  { key: "lead", label: "Lead" },
  { key: "appointment_scheduled", label: "Appointment Scheduled" },
  { key: "demo_given", label: "Demo Given" },
  { key: "contract_sent", label: "Contract Sent" },
  { key: "closed_won", label: "Closed Won" },
  { key: "closed_lost", label: "Closed Lost" },
] as const;

export type StageKey = typeof STAGES[number]["key"];

export const STAGE_COLORS: Record<string, string> = {
  lead: "bg-blue-100 text-blue-800 border-blue-200",
  appointment_scheduled: "bg-purple-100 text-purple-800 border-purple-200",
  demo_given: "bg-amber-100 text-amber-800 border-amber-200",
  contract_sent: "bg-orange-100 text-orange-800 border-orange-200",
  closed_won: "bg-green-100 text-green-800 border-green-200",
  closed_lost: "bg-red-100 text-red-700 border-red-200",
};

export const ACTIVITY_ICONS: Record<string, string> = {
  note: "FileText",
  meeting: "Users",
  call: "Phone",
};

export function stageLabel(key: string): string {
  return STAGES.find((s) => s.key === key)?.label ?? key;
}
