import { ActivityType, DealStage } from "@workspace/api-client-react/src/generated/api.schemas";
import {
  Phone,
  Video,
  StickyNote,
  Briefcase,
  Users,
  Building,
  LayoutDashboard,
  KanbanSquare
} from "lucide-react";

export const STAGES_IN_ORDER: DealStage[] = [
  "lead",
  "appointment_scheduled",
  "demo_given",
  "contract_sent",
  "closed_won",
  "closed_lost",
];

export const STAGE_LABELS: Record<DealStage, string> = {
  lead: "Lead",
  appointment_scheduled: "Appt. Scheduled",
  demo_given: "Demo Given",
  contract_sent: "Contract Sent",
  closed_won: "Closed Won",
  closed_lost: "Closed Lost",
};

export const STAGE_COLORS: Record<DealStage, string> = {
  lead: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300",
  appointment_scheduled: "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300",
  demo_given: "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300",
  contract_sent: "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300",
  closed_won: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300",
  closed_lost: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300",
};

export const ACTIVITY_ICONS: Record<ActivityType, any> = {
  note: StickyNote,
  meeting: Video,
  call: Phone,
};

export const ACTIVITY_COLORS: Record<ActivityType, string> = {
  note: "text-blue-500",
  meeting: "text-purple-500",
  call: "text-amber-500",
};

export const NAVIGATION_ITEMS = [
  { href: "/", label: "Dashboard", icon: LayoutDashboard },
  { href: "/pipeline", label: "Pipeline", icon: KanbanSquare },
  { href: "/deals", label: "Deals", icon: Briefcase },
  { href: "/contacts", label: "Contacts", icon: Users },
  { href: "/companies", label: "Companies", icon: Building },
];

export const formatCurrency = (value: number | null | undefined, currency: string = "USD") => {
  if (value == null) return "—";
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: currency,
    maximumFractionDigits: 0,
  }).format(value);
};
