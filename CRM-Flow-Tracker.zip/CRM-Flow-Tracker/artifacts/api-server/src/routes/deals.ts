import { Router, type IRouter } from "express";
import { eq, ilike, or } from "drizzle-orm";
import { db, dealsTable, contactsTable, companiesTable } from "@workspace/db";
import {
  CreateDealBody,
  UpdateDealBody,
  GetDealParams,
  UpdateDealParams,
  DeleteDealParams,
  ListDealsQueryParams,
} from "@workspace/api-zod";
import { sql } from "drizzle-orm";

const router: IRouter = Router();

async function getDealWithRelations(id: number) {
  const rows = await db
    .select({
      id: dealsTable.id,
      title: dealsTable.title,
      stage: dealsTable.stage,
      capex: dealsTable.capex,
      opex: dealsTable.opex,
      currency: dealsTable.currency,
      probability: dealsTable.probability,
      expectedCloseDate: dealsTable.expectedCloseDate,
      contactId: dealsTable.contactId,
      companyId: dealsTable.companyId,
      contactName: sql<string | null>`CASE WHEN ${contactsTable.id} IS NOT NULL THEN concat(${contactsTable.firstName}, ' ', ${contactsTable.lastName}) ELSE NULL END`,
      companyName: companiesTable.name,
      description: dealsTable.description,
      createdAt: dealsTable.createdAt,
      updatedAt: dealsTable.updatedAt,
    })
    .from(dealsTable)
    .leftJoin(contactsTable, eq(dealsTable.contactId, contactsTable.id))
    .leftJoin(companiesTable, eq(dealsTable.companyId, companiesTable.id))
    .where(eq(dealsTable.id, id));

  if (!rows[0]) return null;

  const row = rows[0];
  const capex = row.capex ? parseFloat(row.capex) : null;
  const opex = row.opex ? parseFloat(row.opex) : null;
  const totalValue = (capex ?? 0) + (opex ?? 0);

  return {
    ...row,
    capex,
    opex,
    totalValue,
  };
}

router.get("/deals", async (req, res): Promise<void> => {
  const queryParams = ListDealsQueryParams.safeParse(req.query);
  const stage = queryParams.success ? queryParams.data.stage : undefined;
  const search = queryParams.success ? queryParams.data.search : undefined;

  const rows = await db
    .select({
      id: dealsTable.id,
      title: dealsTable.title,
      stage: dealsTable.stage,
      capex: dealsTable.capex,
      opex: dealsTable.opex,
      currency: dealsTable.currency,
      probability: dealsTable.probability,
      expectedCloseDate: dealsTable.expectedCloseDate,
      contactId: dealsTable.contactId,
      companyId: dealsTable.companyId,
      contactName: sql<string | null>`CASE WHEN ${contactsTable.id} IS NOT NULL THEN concat(${contactsTable.firstName}, ' ', ${contactsTable.lastName}) ELSE NULL END`,
      companyName: companiesTable.name,
      description: dealsTable.description,
      createdAt: dealsTable.createdAt,
      updatedAt: dealsTable.updatedAt,
    })
    .from(dealsTable)
    .leftJoin(contactsTable, eq(dealsTable.contactId, contactsTable.id))
    .leftJoin(companiesTable, eq(dealsTable.companyId, companiesTable.id))
    .where(
      stage && search
        ? or(eq(dealsTable.stage, stage), ilike(dealsTable.title, `%${search}%`))
        : stage
          ? eq(dealsTable.stage, stage)
          : search
            ? ilike(dealsTable.title, `%${search}%`)
            : undefined
    )
    .orderBy(dealsTable.createdAt);

  const result = rows.map((row) => {
    const capex = row.capex ? parseFloat(row.capex) : null;
    const opex = row.opex ? parseFloat(row.opex) : null;
    const totalValue = (capex ?? 0) + (opex ?? 0);
    return { ...row, capex, opex, totalValue };
  });

  res.json(result);
});

router.post("/deals", async (req, res): Promise<void> => {
  const parsed = CreateDealBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [deal] = await db.insert(dealsTable).values({
    ...parsed.data,
    capex: parsed.data.capex != null ? String(parsed.data.capex) : null,
    opex: parsed.data.opex != null ? String(parsed.data.opex) : null,
  }).returning();

  const full = await getDealWithRelations(deal.id);
  res.status(201).json(full);
});

router.get("/deals/:id", async (req, res): Promise<void> => {
  const params = GetDealParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const deal = await getDealWithRelations(params.data.id);
  if (!deal) {
    res.status(404).json({ error: "Deal not found" });
    return;
  }

  res.json(deal);
});

router.patch("/deals/:id", async (req, res): Promise<void> => {
  const params = UpdateDealParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateDealBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const updateData: Record<string, unknown> = { ...parsed.data };
  if (parsed.data.capex !== undefined) {
    updateData.capex = parsed.data.capex != null ? String(parsed.data.capex) : null;
  }
  if (parsed.data.opex !== undefined) {
    updateData.opex = parsed.data.opex != null ? String(parsed.data.opex) : null;
  }

  const [deal] = await db
    .update(dealsTable)
    .set(updateData)
    .where(eq(dealsTable.id, params.data.id))
    .returning();

  if (!deal) {
    res.status(404).json({ error: "Deal not found" });
    return;
  }

  const full = await getDealWithRelations(deal.id);
  res.json(full);
});

router.delete("/deals/:id", async (req, res): Promise<void> => {
  const params = DeleteDealParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [deal] = await db
    .delete(dealsTable)
    .where(eq(dealsTable.id, params.data.id))
    .returning();

  if (!deal) {
    res.status(404).json({ error: "Deal not found" });
    return;
  }

  res.sendStatus(204);
});

export default router;
