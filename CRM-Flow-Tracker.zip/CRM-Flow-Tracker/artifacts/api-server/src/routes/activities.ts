import { Router, type IRouter } from "express";
import { eq, desc } from "drizzle-orm";
import { db, activitiesTable, dealsTable, contactsTable } from "@workspace/db";
import {
  CreateActivityBody,
  UpdateActivityBody,
  GetActivityParams,
  UpdateActivityParams,
  DeleteActivityParams,
  ListActivitiesQueryParams,
} from "@workspace/api-zod";
import { sql } from "drizzle-orm";

const router: IRouter = Router();

async function getActivityWithRelations(id: number) {
  const rows = await db
    .select({
      id: activitiesTable.id,
      dealId: activitiesTable.dealId,
      contactId: activitiesTable.contactId,
      type: activitiesTable.type,
      title: activitiesTable.title,
      content: activitiesTable.content,
      scheduledAt: activitiesTable.scheduledAt,
      duration: activitiesTable.duration,
      outcome: activitiesTable.outcome,
      dealTitle: dealsTable.title,
      contactName: sql<string | null>`CASE WHEN ${contactsTable.id} IS NOT NULL THEN concat(${contactsTable.firstName}, ' ', ${contactsTable.lastName}) ELSE NULL END`,
      createdAt: activitiesTable.createdAt,
      updatedAt: activitiesTable.updatedAt,
    })
    .from(activitiesTable)
    .leftJoin(dealsTable, eq(activitiesTable.dealId, dealsTable.id))
    .leftJoin(contactsTable, eq(activitiesTable.contactId, contactsTable.id))
    .where(eq(activitiesTable.id, id));

  return rows[0] ?? null;
}

router.get("/activities", async (req, res): Promise<void> => {
  const queryParams = ListActivitiesQueryParams.safeParse(req.query);
  const dealId = queryParams.success ? queryParams.data.dealId : undefined;
  const type = queryParams.success ? queryParams.data.type : undefined;

  const rows = await db
    .select({
      id: activitiesTable.id,
      dealId: activitiesTable.dealId,
      contactId: activitiesTable.contactId,
      type: activitiesTable.type,
      title: activitiesTable.title,
      content: activitiesTable.content,
      scheduledAt: activitiesTable.scheduledAt,
      duration: activitiesTable.duration,
      outcome: activitiesTable.outcome,
      dealTitle: dealsTable.title,
      contactName: sql<string | null>`CASE WHEN ${contactsTable.id} IS NOT NULL THEN concat(${contactsTable.firstName}, ' ', ${contactsTable.lastName}) ELSE NULL END`,
      createdAt: activitiesTable.createdAt,
      updatedAt: activitiesTable.updatedAt,
    })
    .from(activitiesTable)
    .leftJoin(dealsTable, eq(activitiesTable.dealId, dealsTable.id))
    .leftJoin(contactsTable, eq(activitiesTable.contactId, contactsTable.id))
    .where(
      dealId && type
        ? sql`${activitiesTable.dealId} = ${dealId} AND ${activitiesTable.type} = ${type}`
        : dealId
          ? eq(activitiesTable.dealId, dealId)
          : type
            ? eq(activitiesTable.type, type)
            : undefined
    )
    .orderBy(desc(activitiesTable.createdAt));

  res.json(rows);
});

router.post("/activities", async (req, res): Promise<void> => {
  const parsed = CreateActivityBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const insertData = {
    ...parsed.data,
    scheduledAt: parsed.data.scheduledAt ? new Date(parsed.data.scheduledAt) : null,
  };

  const [activity] = await db.insert(activitiesTable).values(insertData).returning();
  const full = await getActivityWithRelations(activity.id);
  res.status(201).json(full);
});

router.get("/activities/:id", async (req, res): Promise<void> => {
  const params = GetActivityParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const activity = await getActivityWithRelations(params.data.id);
  if (!activity) {
    res.status(404).json({ error: "Activity not found" });
    return;
  }

  res.json(activity);
});

router.patch("/activities/:id", async (req, res): Promise<void> => {
  const params = UpdateActivityParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateActivityBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const updateData: Record<string, unknown> = { ...parsed.data };
  if (parsed.data.scheduledAt !== undefined) {
    updateData.scheduledAt = parsed.data.scheduledAt ? new Date(parsed.data.scheduledAt) : null;
  }

  const [activity] = await db
    .update(activitiesTable)
    .set(updateData)
    .where(eq(activitiesTable.id, params.data.id))
    .returning();

  if (!activity) {
    res.status(404).json({ error: "Activity not found" });
    return;
  }

  const full = await getActivityWithRelations(activity.id);
  res.json(full);
});

router.delete("/activities/:id", async (req, res): Promise<void> => {
  const params = DeleteActivityParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [activity] = await db
    .delete(activitiesTable)
    .where(eq(activitiesTable.id, params.data.id))
    .returning();

  if (!activity) {
    res.status(404).json({ error: "Activity not found" });
    return;
  }

  res.sendStatus(204);
});

export default router;
