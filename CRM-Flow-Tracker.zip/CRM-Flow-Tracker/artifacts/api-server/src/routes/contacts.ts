import { Router, type IRouter } from "express";
import { eq, ilike, or } from "drizzle-orm";
import { db, contactsTable, companiesTable } from "@workspace/db";
import {
  CreateContactBody,
  UpdateContactBody,
  GetContactParams,
  UpdateContactParams,
  DeleteContactParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/contacts", async (req, res): Promise<void> => {
  const search = typeof req.query.search === "string" ? req.query.search : undefined;

  const rows = await db
    .select({
      id: contactsTable.id,
      firstName: contactsTable.firstName,
      lastName: contactsTable.lastName,
      email: contactsTable.email,
      phone: contactsTable.phone,
      jobTitle: contactsTable.jobTitle,
      companyId: contactsTable.companyId,
      companyName: companiesTable.name,
      notes: contactsTable.notes,
      createdAt: contactsTable.createdAt,
      updatedAt: contactsTable.updatedAt,
    })
    .from(contactsTable)
    .leftJoin(companiesTable, eq(contactsTable.companyId, companiesTable.id))
    .where(
      search
        ? or(
            ilike(contactsTable.firstName, `%${search}%`),
            ilike(contactsTable.lastName, `%${search}%`),
            ilike(contactsTable.email, `%${search}%`)
          )
        : undefined
    )
    .orderBy(contactsTable.createdAt);

  res.json(rows);
});

router.post("/contacts", async (req, res): Promise<void> => {
  const parsed = CreateContactBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [contact] = await db.insert(contactsTable).values(parsed.data).returning();
  const companyName = parsed.data.companyId
    ? (await db.select({ name: companiesTable.name }).from(companiesTable).where(eq(companiesTable.id, parsed.data.companyId)))[0]?.name ?? null
    : null;

  res.status(201).json({ ...contact, companyName });
});

router.get("/contacts/:id", async (req, res): Promise<void> => {
  const params = GetContactParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const rows = await db
    .select({
      id: contactsTable.id,
      firstName: contactsTable.firstName,
      lastName: contactsTable.lastName,
      email: contactsTable.email,
      phone: contactsTable.phone,
      jobTitle: contactsTable.jobTitle,
      companyId: contactsTable.companyId,
      companyName: companiesTable.name,
      notes: contactsTable.notes,
      createdAt: contactsTable.createdAt,
      updatedAt: contactsTable.updatedAt,
    })
    .from(contactsTable)
    .leftJoin(companiesTable, eq(contactsTable.companyId, companiesTable.id))
    .where(eq(contactsTable.id, params.data.id));

  if (!rows[0]) {
    res.status(404).json({ error: "Contact not found" });
    return;
  }

  res.json(rows[0]);
});

router.patch("/contacts/:id", async (req, res): Promise<void> => {
  const params = UpdateContactParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateContactBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [contact] = await db
    .update(contactsTable)
    .set(parsed.data)
    .where(eq(contactsTable.id, params.data.id))
    .returning();

  if (!contact) {
    res.status(404).json({ error: "Contact not found" });
    return;
  }

  const companyName = contact.companyId
    ? (await db.select({ name: companiesTable.name }).from(companiesTable).where(eq(companiesTable.id, contact.companyId)))[0]?.name ?? null
    : null;

  res.json({ ...contact, companyName });
});

router.delete("/contacts/:id", async (req, res): Promise<void> => {
  const params = DeleteContactParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [contact] = await db
    .delete(contactsTable)
    .where(eq(contactsTable.id, params.data.id))
    .returning();

  if (!contact) {
    res.status(404).json({ error: "Contact not found" });
    return;
  }

  res.sendStatus(204);
});

export default router;
