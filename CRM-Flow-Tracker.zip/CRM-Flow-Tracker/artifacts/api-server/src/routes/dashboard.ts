import { Router, type IRouter } from "express";
import { eq, desc, sql, and, gte, lte } from "drizzle-orm";
import { db, dealsTable, contactsTable, companiesTable, activitiesTable } from "@workspace/db";

const router: IRouter = Router();

router.get("/dashboard/summary", async (_req, res): Promise<void> => {
  const [dealsStats] = await db
    .select({
      totalDeals: sql<number>`count(*)::int`,
      openDeals: sql<number>`count(*) filter (where ${dealsTable.stage} not in ('closed_won', 'closed_lost'))::int`,
      wonDeals: sql<number>`count(*) filter (where ${dealsTable.stage} = 'closed_won')::int`,
      lostDeals: sql<number>`count(*) filter (where ${dealsTable.stage} = 'closed_lost')::int`,
      totalPipelineValue: sql<number>`coalesce(sum(case when ${dealsTable.stage} not in ('closed_won','closed_lost') then coalesce(${dealsTable.capex}::numeric,0) + coalesce(${dealsTable.opex}::numeric,0) else 0 end), 0)`,
      totalCapex: sql<number>`coalesce(sum(coalesce(${dealsTable.capex}::numeric, 0)), 0)`,
      totalOpex: sql<number>`coalesce(sum(coalesce(${dealsTable.opex}::numeric, 0)), 0)`,
      wonValue: sql<number>`coalesce(sum(case when ${dealsTable.stage} = 'closed_won' then coalesce(${dealsTable.capex}::numeric,0) + coalesce(${dealsTable.opex}::numeric,0) else 0 end), 0)`,
    })
    .from(dealsTable);

  const [contactsCount] = await db
    .select({ totalContacts: sql<number>`count(*)::int` })
    .from(contactsTable);

  const [companiesCount] = await db
    .select({ totalCompanies: sql<number>`count(*)::int` })
    .from(companiesTable);

  res.json({
    totalDeals: dealsStats.totalDeals,
    totalContacts: contactsCount.totalContacts,
    totalCompanies: companiesCount.totalCompanies,
    openDeals: dealsStats.openDeals,
    wonDeals: dealsStats.wonDeals,
    lostDeals: dealsStats.lostDeals,
    totalPipelineValue: Number(dealsStats.totalPipelineValue),
    totalCapex: Number(dealsStats.totalCapex),
    totalOpex: Number(dealsStats.totalOpex),
    wonValue: Number(dealsStats.wonValue),
  });
});

router.get("/dashboard/pipeline", async (req, res): Promise<void> => {
  const stages = [
    "lead",
    "appointment_scheduled",
    "demo_given",
    "contract_sent",
    "closed_won",
    "closed_lost",
  ];

  // Optional date range filter on createdAt
  const { startDate, endDate } = req.query as Record<string, string | undefined>;
  const conditions = [];
  if (startDate) {
    const d = new Date(startDate);
    if (!isNaN(d.getTime())) conditions.push(gte(dealsTable.createdAt, d));
  }
  if (endDate) {
    const d = new Date(endDate);
    if (!isNaN(d.getTime())) {
      // Include the full end day
      d.setHours(23, 59, 59, 999);
      conditions.push(lte(dealsTable.createdAt, d));
    }
  }

  const rows = await db
    .select({
      stage: dealsTable.stage,
      count: sql<number>`count(*)::int`,
      totalCapex: sql<number>`coalesce(sum(coalesce(${dealsTable.capex}::numeric, 0)), 0)`,
      totalOpex: sql<number>`coalesce(sum(coalesce(${dealsTable.opex}::numeric, 0)), 0)`,
    })
    .from(dealsTable)
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .groupBy(dealsTable.stage);

  const stageMap = new Map(rows.map((r) => [r.stage, r]));

  const result = stages.map((stage) => {
    const r = stageMap.get(stage);
    const totalCapex = r ? Number(r.totalCapex) : 0;
    const totalOpex = r ? Number(r.totalOpex) : 0;
    return {
      stage,
      count: r ? r.count : 0,
      totalValue: totalCapex + totalOpex,
      totalCapex,
      totalOpex,
    };
  });

  res.json(result);
});

// Returns individual deals for a specific stage, respecting the same date filter
router.get("/dashboard/stage-deals", async (req, res): Promise<void> => {
  const { stage, startDate, endDate } = req.query as Record<string, string | undefined>;

  if (!stage) {
    res.status(400).json({ error: "stage is required" });
    return;
  }

  const conditions: any[] = [eq(dealsTable.stage, stage)];

  if (startDate) {
    const d = new Date(startDate);
    if (!isNaN(d.getTime())) conditions.push(gte(dealsTable.createdAt, d));
  }
  if (endDate) {
    const d = new Date(endDate);
    if (!isNaN(d.getTime())) {
      d.setHours(23, 59, 59, 999);
      conditions.push(lte(dealsTable.createdAt, d));
    }
  }

  const rows = await db
    .select({
      id: dealsTable.id,
      title: dealsTable.title,
      stage: dealsTable.stage,
      capex: dealsTable.capex,
      opex: dealsTable.opex,
      probability: dealsTable.probability,
      expectedCloseDate: dealsTable.expectedCloseDate,
      assignedTo: dealsTable.assignedTo,
      source: dealsTable.source,
      contactName: sql<string | null>`CASE WHEN ${contactsTable.id} IS NOT NULL THEN concat(${contactsTable.firstName}, ' ', ${contactsTable.lastName}) ELSE NULL END`,
      companyName: companiesTable.name,
      createdAt: dealsTable.createdAt,
    })
    .from(dealsTable)
    .leftJoin(contactsTable, eq(dealsTable.contactId, contactsTable.id))
    .leftJoin(companiesTable, eq(dealsTable.companyId, companiesTable.id))
    .where(and(...conditions))
    .orderBy(desc(sql`coalesce(${dealsTable.capex}::numeric,0) + coalesce(${dealsTable.opex}::numeric,0)`));

  res.json(rows.map((r) => ({
    ...r,
    capex: r.capex ? parseFloat(r.capex) : null,
    opex: r.opex ? parseFloat(r.opex) : null,
    totalValue: (r.capex ? parseFloat(r.capex) : 0) + (r.opex ? parseFloat(r.opex) : 0),
  })));
});

router.get("/dashboard/recent-activity", async (req, res): Promise<void> => {
  const limitRaw = req.query.limit;
  const limit = typeof limitRaw === "string" ? Math.min(parseInt(limitRaw, 10) || 10, 50) : 10;

  const rows = await db
    .select({
      id: activitiesTable.id,
      dealId: activitiesTable.dealId,
      contactId: activitiesTable.contactId,
      type: activitiesTable.type,
      title: activitiesTable.title,
      content: activitiesTable.content,
      scheduledAt: activitiesTable.scheduledAt,
      duration: activitiesTable.duration,
      outcome: activitiesTable.outcome,
      dealTitle: dealsTable.title,
      contactName: sql<string | null>`CASE WHEN ${contactsTable.id} IS NOT NULL THEN concat(${contactsTable.firstName}, ' ', ${contactsTable.lastName}) ELSE NULL END`,
      createdAt: activitiesTable.createdAt,
      updatedAt: activitiesTable.updatedAt,
    })
    .from(activitiesTable)
    .leftJoin(dealsTable, eq(activitiesTable.dealId, dealsTable.id))
    .leftJoin(contactsTable, eq(activitiesTable.contactId, contactsTable.id))
    .orderBy(desc(activitiesTable.createdAt))
    .limit(limit);

  res.json(rows);
});

export default router;
