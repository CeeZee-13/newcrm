import { Router, type IRouter } from "express";
import { eq, sql, and, gte, lte } from "drizzle-orm";
import { db, dealsTable, contactsTable, activitiesTable } from "@workspace/db";

const router: IRouter = Router();

// Shared helper to run date-filtered queries
function monthRange(monthsBack: number): { start: Date; end: Date } {
  const now = new Date();
  const start = new Date(now.getFullYear(), now.getMonth() - monthsBack, 1);
  const end = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59);
  return { start, end };
}

// ── Closed Won Summary ───────────────────────────────────────────────────────
router.get("/analytics/closed-won", async (req, res): Promise<void> => {
  const { startDate, endDate } = req.query as Record<string, string | undefined>;

  const conditions: any[] = [eq(dealsTable.stage, "closed_won")];
  if (startDate) {
    const d = new Date(startDate);
    if (!isNaN(d.getTime())) conditions.push(gte(dealsTable.createdAt, d));
  }
  if (endDate) {
    const d = new Date(endDate);
    if (!isNaN(d.getTime())) {
      d.setHours(23, 59, 59, 999);
      conditions.push(lte(dealsTable.createdAt, d));
    }
  }

  const [won] = await db
    .select({
      count: sql<number>`count(*)::int`,
      totalValue: sql<number>`coalesce(sum(coalesce(${dealsTable.capex}::numeric,0) + coalesce(${dealsTable.opex}::numeric,0)),0)`,
      totalMrr: sql<number>`coalesce(sum(coalesce(${dealsTable.mrr}::numeric,0)),0)`,
      avgDealSize: sql<number>`coalesce(avg(coalesce(${dealsTable.capex}::numeric,0) + coalesce(${dealsTable.opex}::numeric,0)),0)`,
      avgMrr: sql<number>`coalesce(avg(coalesce(${dealsTable.mrr}::numeric,0)),0)`,
    })
    .from(dealsTable)
    .where(and(...conditions));

  res.json({
    count: won.count,
    totalValue: Number(won.totalValue),
    totalMrr: Number(won.totalMrr),
    avgDealSize: Number(won.avgDealSize),
    avgMrr: Number(won.avgMrr),
  });
});

// ── Closed Won vs Goal ───────────────────────────────────────────────────────
router.get("/analytics/closed-won-vs-goal", async (_req, res): Promise<void> => {
  const goal = 2000000; // Annual revenue goal
  const mrrGoal = 150000; // Annual MRR goal

  const [won] = await db
    .select({
      totalValue: sql<number>`coalesce(sum(coalesce(${dealsTable.capex}::numeric,0) + coalesce(${dealsTable.opex}::numeric,0)),0)`,
      totalMrr: sql<number>`coalesce(sum(coalesce(${dealsTable.mrr}::numeric,0)),0)`,
      count: sql<number>`count(*)::int`,
    })
    .from(dealsTable)
    .where(eq(dealsTable.stage, "closed_won"));

  const totalValue = Number(won.totalValue);
  const totalMrr = Number(won.totalMrr);

  res.json({
    wonValue: totalValue,
    wonMrr: totalMrr,
    revenueGoal: goal,
    mrrGoal,
    revenuePercent: Math.round((totalValue / goal) * 100),
    mrrPercent: Math.round((totalMrr / mrrGoal) * 100),
    wonCount: won.count,
  });
});

// ── Pipeline Report ──────────────────────────────────────────────────────────
router.get("/analytics/pipeline-report", async (_req, res): Promise<void> => {
  const stages = ["lead", "appointment_scheduled", "demo_given", "contract_sent", "closed_won", "closed_lost"];

  const rows = await db
    .select({
      stage: dealsTable.stage,
      count: sql<number>`count(*)::int`,
      totalCapex: sql<number>`coalesce(sum(coalesce(${dealsTable.capex}::numeric,0)),0)`,
      totalOpex: sql<number>`coalesce(sum(coalesce(${dealsTable.opex}::numeric,0)),0)`,
      avgProbability: sql<number>`coalesce(avg(${dealsTable.probability}),0)`,
      weightedValue: sql<number>`coalesce(sum((coalesce(${dealsTable.capex}::numeric,0) + coalesce(${dealsTable.opex}::numeric,0)) * coalesce(${dealsTable.probability}::numeric,0) / 100),0)`,
    })
    .from(dealsTable)
    .groupBy(dealsTable.stage);

  const stageMap = new Map(rows.map((r) => [r.stage, r]));
  const result = stages.map((stage) => {
    const r = stageMap.get(stage);
    const totalCapex = r ? Number(r.totalCapex) : 0;
    const totalOpex = r ? Number(r.totalOpex) : 0;
    return {
      stage,
      count: r ? r.count : 0,
      totalValue: totalCapex + totalOpex,
      totalCapex,
      totalOpex,
      avgProbability: r ? Math.round(Number(r.avgProbability)) : 0,
      weightedValue: r ? Number(r.weightedValue) : 0,
    };
  });

  res.json(result);
});

// ── Calls by Rep ─────────────────────────────────────────────────────────────
router.get("/analytics/calls-by-rep", async (_req, res): Promise<void> => {
  const rows = await db
    .select({
      rep: activitiesTable.rep,
      totalCalls: sql<number>`count(*)::int`,
      connectedCalls: sql<number>`count(*) filter (where ${activitiesTable.connected} = true)::int`,
      avgDuration: sql<number>`coalesce(avg(${activitiesTable.duration}) filter (where ${activitiesTable.connected} = true), 0)`,
    })
    .from(activitiesTable)
    .where(eq(activitiesTable.type, "call"))
    .groupBy(activitiesTable.rep);

  const result = rows
    .filter((r) => r.rep)
    .map((r) => ({
      rep: r.rep!,
      totalCalls: r.totalCalls,
      connectedCalls: r.connectedCalls,
      connectionRate: r.totalCalls > 0 ? Math.round((r.connectedCalls / r.totalCalls) * 100) : 0,
      avgDuration: Math.round(Number(r.avgDuration)),
    }))
    .sort((a, b) => b.totalCalls - a.totalCalls);

  res.json(result);
});

// ── Connected Calls Trend (monthly, 12 months) ───────────────────────────────
router.get("/analytics/calls-trend", async (_req, res): Promise<void> => {
  const rows = await db
    .select({
      month: sql<string>`to_char(date_trunc('month', ${activitiesTable.createdAt}), 'YYYY-MM')`,
      totalCalls: sql<number>`count(*)::int`,
      connectedCalls: sql<number>`count(*) filter (where ${activitiesTable.connected} = true)::int`,
    })
    .from(activitiesTable)
    .where(
      and(
        eq(activitiesTable.type, "call"),
        gte(activitiesTable.createdAt, monthRange(12).start),
      )
    )
    .groupBy(sql`date_trunc('month', ${activitiesTable.createdAt})`)
    .orderBy(sql`date_trunc('month', ${activitiesTable.createdAt})`);

  res.json(rows.map((r) => ({
    month: r.month,
    totalCalls: r.totalCalls,
    connectedCalls: r.connectedCalls,
    connectionRate: r.totalCalls > 0 ? Math.round((r.connectedCalls / r.totalCalls) * 100) : 0,
  })));
});

// ── Meetings by Rep ──────────────────────────────────────────────────────────
router.get("/analytics/meetings-by-rep", async (_req, res): Promise<void> => {
  const rows = await db
    .select({
      rep: activitiesTable.rep,
      totalMeetings: sql<number>`count(*)::int`,
      avgDuration: sql<number>`coalesce(avg(${activitiesTable.duration}), 0)`,
    })
    .from(activitiesTable)
    .where(eq(activitiesTable.type, "meeting"))
    .groupBy(activitiesTable.rep);

  const result = rows
    .filter((r) => r.rep)
    .map((r) => ({
      rep: r.rep!,
      totalMeetings: r.totalMeetings,
      avgDuration: Math.round(Number(r.avgDuration)),
    }))
    .sort((a, b) => b.totalMeetings - a.totalMeetings);

  res.json(result);
});

// ── Meetings Trend (monthly, 12 months) ─────────────────────────────────────
router.get("/analytics/meetings-trend", async (_req, res): Promise<void> => {
  const rows = await db
    .select({
      month: sql<string>`to_char(date_trunc('month', ${activitiesTable.createdAt}), 'YYYY-MM')`,
      totalMeetings: sql<number>`count(*)::int`,
    })
    .from(activitiesTable)
    .where(
      and(
        eq(activitiesTable.type, "meeting"),
        gte(activitiesTable.createdAt, monthRange(12).start),
      )
    )
    .groupBy(sql`date_trunc('month', ${activitiesTable.createdAt})`)
    .orderBy(sql`date_trunc('month', ${activitiesTable.createdAt})`);

  res.json(rows.map((r) => ({
    month: r.month,
    totalMeetings: r.totalMeetings,
  })));
});

// ── Deals Won vs Lost ────────────────────────────────────────────────────────
router.get("/analytics/deals-won-lost", async (_req, res): Promise<void> => {
  const rows = await db
    .select({
      month: sql<string>`to_char(date_trunc('month', ${dealsTable.createdAt}), 'YYYY-MM')`,
      stage: dealsTable.stage,
      count: sql<number>`count(*)::int`,
      totalValue: sql<number>`coalesce(sum(coalesce(${dealsTable.capex}::numeric,0) + coalesce(${dealsTable.opex}::numeric,0)),0)`,
    })
    .from(dealsTable)
    .where(
      and(
        sql`${dealsTable.stage} in ('closed_won', 'closed_lost')`,
        gte(dealsTable.createdAt, monthRange(12).start),
      )
    )
    .groupBy(sql`date_trunc('month', ${dealsTable.createdAt})`, dealsTable.stage)
    .orderBy(sql`date_trunc('month', ${dealsTable.createdAt})`);

  // Pivot by month
  const monthMap = new Map<string, { month: string; wonCount: number; lostCount: number; wonValue: number; lostValue: number }>();
  for (const row of rows) {
    if (!monthMap.has(row.month)) {
      monthMap.set(row.month, { month: row.month, wonCount: 0, lostCount: 0, wonValue: 0, lostValue: 0 });
    }
    const entry = monthMap.get(row.month)!;
    if (row.stage === "closed_won") {
      entry.wonCount = row.count;
      entry.wonValue = Number(row.totalValue);
    } else {
      entry.lostCount = row.count;
      entry.lostValue = Number(row.totalValue);
    }
  }

  res.json(Array.from(monthMap.values()));
});

// ── MRR Closed Won Annual Performance ────────────────────────────────────────
router.get("/analytics/mrr-performance", async (_req, res): Promise<void> => {
  const rows = await db
    .select({
      month: sql<string>`to_char(date_trunc('month', ${dealsTable.createdAt}), 'YYYY-MM')`,
      totalMrr: sql<number>`coalesce(sum(coalesce(${dealsTable.mrr}::numeric,0)),0)`,
      count: sql<number>`count(*)::int`,
      totalValue: sql<number>`coalesce(sum(coalesce(${dealsTable.capex}::numeric,0) + coalesce(${dealsTable.opex}::numeric,0)),0)`,
    })
    .from(dealsTable)
    .where(
      and(
        eq(dealsTable.stage, "closed_won"),
        gte(dealsTable.createdAt, monthRange(12).start),
      )
    )
    .groupBy(sql`date_trunc('month', ${dealsTable.createdAt})`)
    .orderBy(sql`date_trunc('month', ${dealsTable.createdAt})`);

  res.json(rows.map((r) => ({
    month: r.month,
    totalMrr: Number(r.totalMrr),
    count: r.count,
    totalValue: Number(r.totalValue),
  })));
});

// ── Average MRR Deal Size by Rep ─────────────────────────────────────────────
router.get("/analytics/avg-mrr", async (_req, res): Promise<void> => {
  const [overall] = await db
    .select({
      avgMrr: sql<number>`coalesce(avg(coalesce(${dealsTable.mrr}::numeric,0)),0)`,
      avgDealSize: sql<number>`coalesce(avg(coalesce(${dealsTable.capex}::numeric,0) + coalesce(${dealsTable.opex}::numeric,0)),0)`,
    })
    .from(dealsTable)
    .where(eq(dealsTable.stage, "closed_won"));

  const byRep = await db
    .select({
      rep: dealsTable.assignedTo,
      avgMrr: sql<number>`coalesce(avg(coalesce(${dealsTable.mrr}::numeric,0)),0)`,
      avgDealSize: sql<number>`coalesce(avg(coalesce(${dealsTable.capex}::numeric,0) + coalesce(${dealsTable.opex}::numeric,0)),0)`,
      wonCount: sql<number>`count(*)::int`,
    })
    .from(dealsTable)
    .where(eq(dealsTable.stage, "closed_won"))
    .groupBy(dealsTable.assignedTo);

  res.json({
    overallAvgMrr: Number(overall.avgMrr),
    overallAvgDealSize: Number(overall.avgDealSize),
    byRep: byRep
      .filter((r) => r.rep)
      .map((r) => ({
        rep: r.rep!,
        avgMrr: Number(r.avgMrr),
        avgDealSize: Number(r.avgDealSize),
        wonCount: r.wonCount,
      }))
      .sort((a, b) => b.avgMrr - a.avgMrr),
  });
});

// ── Deals Aging Report ───────────────────────────────────────────────────────
router.get("/analytics/deals-aging", async (_req, res): Promise<void> => {
  const rows = await db
    .select({
      id: dealsTable.id,
      title: dealsTable.title,
      stage: dealsTable.stage,
      assignedTo: dealsTable.assignedTo,
      createdAt: dealsTable.createdAt,
      totalValue: sql<number>`coalesce(${dealsTable.capex}::numeric,0) + coalesce(${dealsTable.opex}::numeric,0)`,
      daysOpen: sql<number>`extract(day from now() - ${dealsTable.createdAt})::int`,
    })
    .from(dealsTable)
    .where(sql`${dealsTable.stage} not in ('closed_won', 'closed_lost')`)
    .orderBy(sql`extract(day from now() - ${dealsTable.createdAt}) desc`);

  const buckets = {
    "0-14 days": 0,
    "15-30 days": 0,
    "31-60 days": 0,
    "61-90 days": 0,
    "90+ days": 0,
  };

  for (const r of rows) {
    const d = r.daysOpen;
    if (d <= 14) buckets["0-14 days"]++;
    else if (d <= 30) buckets["15-30 days"]++;
    else if (d <= 60) buckets["31-60 days"]++;
    else if (d <= 90) buckets["61-90 days"]++;
    else buckets["90+ days"]++;
  }

  res.json({
    deals: rows.map((r) => ({
      id: r.id,
      title: r.title,
      stage: r.stage,
      assignedTo: r.assignedTo,
      daysOpen: r.daysOpen,
      totalValue: Number(r.totalValue),
    })),
    buckets: Object.entries(buckets).map(([bucket, count]) => ({ bucket, count })),
  });
});

// ── Contacts & Deals Created / Worked / Won ──────────────────────────────────
router.get("/analytics/contacts-worked", async (_req, res): Promise<void> => {
  const [contactStats] = await db
    .select({
      totalContacts: sql<number>`count(*)::int`,
      newThisMonth: sql<number>`count(*) filter (where date_trunc('month', ${contactsTable.createdAt}) = date_trunc('month', now()))::int`,
    })
    .from(contactsTable);

  // Contacts that have at least one activity
  const workedRows = await db
    .select({ count: sql<number>`count(distinct ${activitiesTable.contactId})::int` })
    .from(activitiesTable)
    .where(sql`${activitiesTable.contactId} is not null`);
  const workedCount = workedRows[0]?.count ?? 0;

  const [dealStats] = await db
    .select({
      totalDeals: sql<number>`count(*)::int`,
      newThisMonth: sql<number>`count(*) filter (where date_trunc('month', ${dealsTable.createdAt}) = date_trunc('month', now()))::int`,
      wonTotal: sql<number>`count(*) filter (where ${dealsTable.stage} = 'closed_won')::int`,
      wonThisMonth: sql<number>`count(*) filter (where ${dealsTable.stage} = 'closed_won' and date_trunc('month', ${dealsTable.createdAt}) = date_trunc('month', now()))::int`,
    })
    .from(dealsTable);

  const monthlyRows = await db
    .select({
      month: sql<string>`to_char(date_trunc('month', ${contactsTable.createdAt}), 'YYYY-MM')`,
      contactsCreated: sql<number>`count(*)::int`,
    })
    .from(contactsTable)
    .where(gte(contactsTable.createdAt, monthRange(12).start))
    .groupBy(sql`date_trunc('month', ${contactsTable.createdAt})`)
    .orderBy(sql`date_trunc('month', ${contactsTable.createdAt})`);

  const dealMonthlyRows = await db
    .select({
      month: sql<string>`to_char(date_trunc('month', ${dealsTable.createdAt}), 'YYYY-MM')`,
      dealsCreated: sql<number>`count(*)::int`,
      dealsWon: sql<number>`count(*) filter (where ${dealsTable.stage} = 'closed_won')::int`,
    })
    .from(dealsTable)
    .where(gte(dealsTable.createdAt, monthRange(12).start))
    .groupBy(sql`date_trunc('month', ${dealsTable.createdAt})`)
    .orderBy(sql`date_trunc('month', ${dealsTable.createdAt})`);

  res.json({
    totalContacts: contactStats.totalContacts,
    contactsNewThisMonth: contactStats.newThisMonth,
    contactsWorked: Number(workedCount),
    totalDeals: dealStats.totalDeals,
    dealsNewThisMonth: dealStats.newThisMonth,
    dealsWonTotal: dealStats.wonTotal,
    dealsWonThisMonth: dealStats.wonThisMonth,
    monthlyTrend: monthlyRows.map((r) => {
      const dm = dealMonthlyRows.find((d) => d.month === r.month);
      return {
        month: r.month,
        contactsCreated: r.contactsCreated,
        dealsCreated: dm?.dealsCreated ?? 0,
        dealsWon: dm?.dealsWon ?? 0,
      };
    }),
  });
});

// ── Revenue by Source ────────────────────────────────────────────────────────
router.get("/analytics/revenue-by-source", async (_req, res): Promise<void> => {
  const rows = await db
    .select({
      source: dealsTable.source,
      count: sql<number>`count(*)::int`,
      wonCount: sql<number>`count(*) filter (where ${dealsTable.stage} = 'closed_won')::int`,
      totalValue: sql<number>`coalesce(sum(coalesce(${dealsTable.capex}::numeric,0) + coalesce(${dealsTable.opex}::numeric,0)),0)`,
      wonValue: sql<number>`coalesce(sum(case when ${dealsTable.stage} = 'closed_won' then coalesce(${dealsTable.capex}::numeric,0) + coalesce(${dealsTable.opex}::numeric,0) else 0 end),0)`,
      totalMrr: sql<number>`coalesce(sum(case when ${dealsTable.stage} = 'closed_won' then coalesce(${dealsTable.mrr}::numeric,0) else 0 end),0)`,
    })
    .from(dealsTable)
    .groupBy(dealsTable.source)
    .orderBy(sql`coalesce(sum(case when ${dealsTable.stage} = 'closed_won' then coalesce(${dealsTable.capex}::numeric,0) + coalesce(${dealsTable.opex}::numeric,0) else 0 end),0) desc`);

  res.json(rows.map((r) => ({
    source: r.source ?? "Unknown",
    count: r.count,
    wonCount: r.wonCount,
    totalValue: Number(r.totalValue),
    wonValue: Number(r.wonValue),
    totalMrr: Number(r.totalMrr),
    winRate: r.count > 0 ? Math.round((r.wonCount / r.count) * 100) : 0,
  })));
});

export default router;
